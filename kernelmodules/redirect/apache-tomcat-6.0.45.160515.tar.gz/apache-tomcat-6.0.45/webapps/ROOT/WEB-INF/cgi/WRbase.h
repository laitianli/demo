#ifndef _WRbase_h_

#define _WRbase_h_

#include<stdio.h>
#include "cJSON.h"

#define CONF_COL_NAME_MAXLEN 33

#define REQ_METHOD "REQUEST_METHOD"
#define REQ_GET_QUERY_STRING  "QUERY_STRING"
#define REQ_CONTENT_LEN "CONTENT_LENGTH"
#define REQ_HTTP_COOKIE  "HTTP_COOKIE"
#define WR_COOKIE_SESSIONID "sessionid"


#define REQ_METHOD_GET "GET"
#define REQ_METHOD_POST "POST"

#define REQ_ACTION "action"



#ifdef _DEBUG_
extern FILE *logfile;
#define WR_LOG_PATH "./webdirect.log"
#define WR_OPEN_DEBUG() \
do{ \
	if(NULL == logfile) \
		logfile = fopen(WR_LOG_PATH, "a+"); \
		if(logfile == NULL) \
			return -1; \
	}while(0)
#define WR_CLOSE_DEBUG() \
do{ \
	if(NULL != logfile) \
		fclose(logfile); \
		logfile = NULL; \
		}while(0)
		
#define WR_DEBUG(args...) fprintf(logfile, args)
#define WR_DEBUG_IF(condition, args...) do{if(condition) fprintf(logfile, args);} while(0)
#define WR_ERR_RET_IF(condition, retcode, args...) do{if(condition){ fprintf(logfile, args); return retcode;}} while(0)
#else
#define WR_DEBUG(args...) do{} while(0)
#define WR_DEBUG_IF(condition, args...) do {} while (0)
#define WR_ERR_RET_IF(condition, retcode, args...) do{if(condition){return retcode;}} while(0)
#endif

#define FREE(v) do { \
				if(v) {\
			   		free(v);\
			  		v = NULL;}\
			}while(0)

extern char *right_trim(char *buff, char delc);
extern char * __getvalue4name(char *buff, char *name, char *value, int nlen, char asplit,char bsplit);

extern char * getvalue4name(char *buff, char *name, char *value, int nlen);

extern char *getparams4request(char *buff, int nlen, int *outlen);

extern void json_print(cJSON *root);
#endif
