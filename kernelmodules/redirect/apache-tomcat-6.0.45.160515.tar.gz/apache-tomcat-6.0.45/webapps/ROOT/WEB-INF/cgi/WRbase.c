#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "WRbase.h"

#ifdef _DEBUG_
FILE *logfile = NULL;
#endif

char *right_trim(char *buff, char delc)
{
	char *temp;
	
	temp = buff;
	while(*temp != delc && *temp != '\0')	
		++temp;
	*temp = '\0';
	return buff;
}

char * __getvalue4name(char *buff, char *name, char *value, int nlen, char asplit,char bsplit)
{
	char *atemp1, *atemp2, *btemp1, *btemp2;
	int outlen;
	
	atemp1 = buff;
	while((atemp2 = strchr(atemp1, asplit)) != NULL || strlen(atemp1) > 2)
	{
			btemp1 = atemp1;
			btemp2 = strchr(btemp1, bsplit);
			/*compare name is or no same*/
			if(strlen(name) == btemp2-btemp1 && !strncmp(name, btemp1, btemp2-btemp1))
			{
				/*get the value if name same*/
				if(atemp2 != NULL)
					outlen =  atemp2-(btemp2+1) > nlen-1? nlen-1:atemp2-(btemp2+1);
				else
					outlen = strlen(btemp2+1);
				strncpy(value, btemp2+1, outlen);
				value[outlen] = '\0';
				return value;	
			}
			if(NULL == atemp2)
				break;
			atemp1 = atemp2+1;	
	}
	return NULL;
}

char * getvalue4name(char *buff, char *name, char *value, int nlen)
{
	return __getvalue4name(buff, name, value, nlen, '&', '=');
}

char *getparams4request(char *buff, int nlen, int *outlen)
{
	char * req_method, *query_string, *temp;
	int olen;
	WR_DEBUG("in getparams4request\n");
	req_method = getenv(REQ_METHOD);
	WR_DEBUG("the reqest method is %s\n", req_method);
	WR_ERR_RET_IF((NULL == req_method), NULL, "get the reqest method error!<br>");
	
	if(!strcmp(req_method, REQ_METHOD_GET))
	{
		query_string = getenv(REQ_GET_QUERY_STRING);
		WR_DEBUG("query string : %s<br>", query_string);
		WR_ERR_RET_IF((NULL == query_string), NULL, "get the reqest query string error!<br>");
		olen = strlen(query_string);
		memset((void *)buff, 0x00, nlen);
		strncpy(buff, query_string, olen > nlen-1? nlen-1:olen);
		*outlen = strlen(buff);
	}
	else if(!strcmp(req_method, REQ_METHOD_POST))
	{
		temp = getenv(REQ_CONTENT_LEN);
		WR_ERR_RET_IF((NULL == temp), NULL, "get the request content len fail!<br>");
		olen = atoi(temp);
		olen++;
		memset(buff, 0x00, nlen);
		WR_ERR_RET_IF((NULL ==  fgets(buff, olen > nlen-1? nlen-1:olen, stdin)), NULL, "get the request content value fail!<br>");
		*outlen = strlen(buff);
	}
	else
	{
		printf("no support this request method of %s\n", req_method);
		return NULL;
	}
	return buff;
}

inline void json_print(cJSON *root)
{
	//char *pJSON = cJSON_Print(root);
	char *pJSON= cJSON_PrintUnformatted(root);
	printf(pJSON == NULL ? "" : pJSON);
	cJSON_Delete(root);
    FREE(pJSON);
}
