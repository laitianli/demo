#ifndef _WRsession_h_

#define _WRsession_h_
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SESSION_NAME_MAXLEN 33
#define SESSION_PASSWD_MAXLEN 33
#define SESSION_ID_MAXLEN 33

#define WR_SESSION_FLAG_LOGIN 1
#define WR_SESSION_FLAG_NOLOGIN 0


typedef struct wr_session {
	int keyid;
	char session_id[SESSION_ID_MAXLEN];
	char name[SESSION_NAME_MAXLEN];
	char passwd[SESSION_PASSWD_MAXLEN];
	int flag;
	time_t last_time;
	time_t avail_time;
}wr_session_t;

extern char * make_sessionid(char *name, char *buff, int nlen);

extern int open_session();

extern void close_session();

extern int islogin_session_checksessionid(char *name, int keyid, char *session, char *newsessionid);

extern int islogin_session_checkpasswd(char *name, int keyid,  char *passwd, char *newsessionid);

extern int login_session(char *name, int keyid, char *passwd, char *sessionid);

extern wr_session_t * __get_session_keyid(int keyid);

extern wr_session_t * __get_session(char *name);

extern wr_session_t * update_session(wr_session_t *session);

#endif
