#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>      
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#include "WRerr.h"
#include "WRbase.h"
#include "WRsession.h"
#include "common.h"

#define WR_CONFSET_PATH "./webredirect.conf"
#define WR_CONFSET_ACTION_GET "get"
#define WR_CONFSET_ACTION_SAVE "save"
#define WR_CONFSET_ACTION_TOKERNEL "tokernel"

#define WR_CONFSET_RATIO_TYPE "ratio_type"
#define WR_CONFSET_RATIO "ratio"
#define WR_CONFSET_URL "url"
#define WR_CONFSET_NETWORK "network"
#define WR_CONFSET_AVAILD "availd"


#define REDIRECT_CONTROL_NAME "/dev/redirect_control"
#define REDIRECT_SET_INFO 			('U'<<24 | 'R'<<16 | 'L' <<8 | 'A')
#define REDIRECT_GET_USER_COUNT  			(REDIRECT_SET_INFO + 1)
#define REDIRECT_GET_USER_DATA  			(REDIRECT_GET_USER_COUNT + 1)

struct redirect_info {
	unsigned long 	red_timeout;		/* redirect timeout */
	unsigned char   red_tag;			/* redirect tag */
	char		 	red_network[10];	/* redirect network */
	char 			red_url[4096];  	/* redirect url */	
};


int save_config_to_kernel(char *file_path, char *dev_path)
{
	FILE *fp;
	int fd;
	char *temp;
	int ret;
	char confinfo[1024];
	char buffer[256];
	struct redirect_info redinfo;
	
	/*get confinfo to file*/
	fp = fopen(file_path, "r");
	memset(confinfo, 0x00, sizeof(confinfo));
	temp = fgets(confinfo, sizeof(confinfo)-1, fp) ;
	if(NULL==temp)
	{
		fclose(fp);
		return -1;
	}
	fclose(fp);
	temp = getvalue4name(confinfo, WR_CONFSET_RATIO_TYPE, buffer, sizeof(buffer));
	temp = getvalue4name(confinfo, WR_CONFSET_RATIO, buffer, sizeof(buffer));
	redinfo.red_timeout = atol(buffer);
	temp = getvalue4name(confinfo, WR_CONFSET_URL, buffer, sizeof(buffer));
	strncpy(redinfo.red_url, buffer, sizeof(redinfo.red_url)-1);
	temp = getvalue4name(confinfo, WR_CONFSET_NETWORK, buffer, sizeof(buffer));
	strncpy(redinfo.red_network, buffer, sizeof(redinfo.red_network)-1);
	temp = getvalue4name(confinfo, WR_CONFSET_AVAILD, buffer, sizeof(buffer));
	redinfo.red_tag = atoi(buffer);
	
	fd = open(REDIRECT_CONTROL_NAME, O_RDWR);
	if(fd < 0)
	{
		WR_DEBUG("[ERROR] open \"%s\" failed\n", REDIRECT_CONTROL_NAME);
		return -1;
	}
	ret = ioctl(fd, REDIRECT_SET_INFO, &redinfo);
	if(ret != 0)
	{
		WR_DEBUG("[ERROR] save \"%s\" failed\n", REDIRECT_CONTROL_NAME);
		return -1;
	}
	return 0;
	
}

int main()
{
	int outlen, nret;
	char *temp;
	char confinfo[1024];
	char action[33];
	char buffer[256];
	char sessionid[65];
	FILE *fp;
	cJSON *node;
	
	WR_OPEN_DEBUG();
	/*if login?*/
	/*nret = islogin_user();
	if(nret < 0)
	{
		WR_DEBUG("system is busy or have some issue!\n");
		return -1;
	}
	else if(nret == 0)
	{
		WR_DEBUG("user no login,please login frist!\n");
		return -1;	
	}*/
	nret = islogin_user_cookie(sessionid, sizeof(sessionid));
	if(nret < 0)
	{
		cgi_error(nret);
		return -1;
	}
	else if(nret == 0)
	{
		cgi_error(ERR_NOT_LOGIN);
		return -1;	
	}
	/*return name and sessionid to client by cookie*/
	printf("Set-Cookie:sessionid=%s\n", sessionid);
	printf("Content-Type:text/html\n\n");
	/*next do config set work*/
	temp = getparams4request(confinfo, 256, &outlen);
	WR_ERR_RET_IF((NULL == temp), -1, "get params from request fail!<br>");
	WR_DEBUG("confinfo:%s", confinfo);
	
	/*get action*/
	temp = getvalue4name(confinfo, REQ_ACTION, action, sizeof(action));
	WR_ERR_RET_IF((NULL == temp), -1, "get action from request fail!<br>");
	if(!strcmp(temp, WR_CONFSET_ACTION_GET))
	{
		/*get confinfo to file*/
		fp = fopen(WR_CONFSET_PATH, "r");
		WR_ERR_RET_IF((NULL == fp), -1, "open the web redirect config file fail!<br>");
		temp = fgets(confinfo, sizeof(confinfo), fp) ;
		if(NULL==temp)
		{
			fclose(fp);
			return -1;
		}
		node = cJSON_CreateObject();

		temp = getvalue4name(confinfo, WR_CONFSET_RATIO_TYPE, buffer, sizeof(buffer));
	  cJSON_AddStringToObject(node, WR_CONFSET_RATIO_TYPE, temp==NULL?"":buffer);
	  temp = getvalue4name(confinfo, WR_CONFSET_RATIO, buffer, sizeof(buffer));
	  cJSON_AddStringToObject(node, WR_CONFSET_RATIO, temp==NULL?"":buffer);
	  temp = getvalue4name(confinfo, WR_CONFSET_URL, buffer, sizeof(buffer));
	  cJSON_AddStringToObject(node, WR_CONFSET_URL, temp==NULL?"":buffer);
	  temp = getvalue4name(confinfo, WR_CONFSET_NETWORK, buffer, sizeof(buffer));
	  cJSON_AddStringToObject(node, WR_CONFSET_NETWORK, temp==NULL?"":buffer);
	  temp = getvalue4name(confinfo, WR_CONFSET_AVAILD, buffer, sizeof(buffer));
	  cJSON_AddStringToObject(node, WR_CONFSET_AVAILD, temp==NULL?"":buffer);
    json_print(node);
    
		fclose(fp);
	}
	else if(!strcmp(temp, WR_CONFSET_ACTION_SAVE))
	{
		/*save confinfo to file*/
		fp = fopen(WR_CONFSET_PATH, "w");
		if(NULL == fp)
			cgi_error(ERR_FAILURE);
		WR_ERR_RET_IF((NULL == fp), -1, "open the web redirect config file fail!<br>");
		/*skip the "action=save&"*/
		nret = fwrite(confinfo+12, outlen-12, 1, fp) ;
		if(nret != 1)
		{
			fclose(fp);
			WR_DEBUG("config info not set success!\n");
			return -1;	
		}
		fflush(fp);
		fclose(fp);
		WR_DEBUG("config info set success!\n");
		cgi_error(ERR_SUCCESS);
	}
	else if(!strcmp(temp, WR_CONFSET_ACTION_TOKERNEL))
	{
		nret = save_config_to_kernel(WR_CONFSET_PATH, REDIRECT_CONTROL_NAME);
		if(nret < 0)
		{
			cgi_error(ERR_SAVETOKERNEL);
			return -1;	
		}
	}
	else
	{
		WR_DEBUG("no support this action!");
		cgi_error(ERR_FAILURE);
		return -1;
	}
	
	
	return 0;
}
