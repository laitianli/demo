#ifndef _WRerr_h_
#define _WRerr_h_

#define ERR_SUCCESS  0             /*successful operation*/
#define ERR_FAILURE  -1           /*failure    operation */
#define ERR_COOKIE  -2             /*cookie timeout, need to login*/
#define ERR_LOGINOUT  -3           /*login out*/
#define ERR_NOT_LOGIN  -4          /*user not  login*/
#define ERR_REPEAT_LOGIN  -5       /*repeat login (a user can login only one place)*/
#define ERR_FILE_NOT_EXIST  -6     /*restart the web server and need to log in again*/
#define ERR_NOTFOUND -9			/*no record found*/


/*config info set*/
#define ERR_SAVETOKERNEL -60

#define WR_NOMEM 100
#define WR_NOFIND 101
#define WR_SESSIONEXIST 102
#define WR_ERR_OPENSESSION 103
#define WR_ERR_LOGINED 104
#define WR_MAXERRNO 105


#define IS_ERR(x) ((unsigned long)(x) >= (unsigned long)-WR_MAXERRNO)

#define ERR_PTR(x) ((void *) x)
#define PTR_ERR(x) ((long) x)

#define cgi_error(err) printf("Content-Type:text/html\n\n"); \
printf("%d", err);

#endif
