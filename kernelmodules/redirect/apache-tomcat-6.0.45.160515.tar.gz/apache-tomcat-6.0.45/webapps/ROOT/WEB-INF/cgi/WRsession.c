#include "WRerr.h"
#include "WRsession.h"

#define WR_SESSION_PATH "./session.data"
#define WR_SESSION_TIMEOUT (60*5)

static FILE *gfp = NULL;

char * make_sessionid(char *name, char *buff, int nlen)
{
	time_t now;
	time(&now);
	memset(buff, 0x00, nlen);
	snprintf(buff, nlen-1, "%s:%ld", name, now);
	return buff;
}

int open_session()
{
	if(gfp != NULL)
		return 0;
	gfp = fopen(WR_SESSION_PATH, "rb+");
	if(NULL == gfp)
		return -WR_ERR_OPENSESSION;
	return 0;
}

void close_session()
{
	if(gfp != NULL)
		fclose(gfp);
	gfp = NULL;
}

wr_session_t * __get_session(char *name)
{
	wr_session_t * session;
	
	if(NULL == gfp)
		return ERR_PTR(-WR_ERR_OPENSESSION);
	session = (wr_session_t *)malloc(sizeof(wr_session_t));
	if(NULL == session)
		return ERR_PTR(-WR_NOMEM);
	/*read the session file*/
	fseek(gfp, 0L, SEEK_SET);
	while(!feof(gfp))
	{
		fread(session, sizeof(wr_session_t), 1, gfp);
		if(!strcmp(session->name, name))
			return session;	
	}
	free(session);
	return NULL;
}

wr_session_t * __get_session_keyid(int keyid)
{
	wr_session_t * session;
	
	if(NULL == gfp)
		return ERR_PTR(-WR_ERR_OPENSESSION);
	/*read the session file*/
	fseek(gfp, 0L, SEEK_END);
	if((keyid+1)*sizeof(wr_session_t) > ftell(gfp))
		return NULL;
	fseek(gfp, sizeof(wr_session_t)*keyid, SEEK_SET);
	session = (wr_session_t *)malloc(sizeof(wr_session_t));
	if(NULL == session)
		return ERR_PTR(-WR_NOMEM);
	fread(session, sizeof(wr_session_t), 1, gfp);
	return session;	
}

wr_session_t * get_session(char *name, char *passwd)
{
	wr_session_t *session;
	time_t now;
	
	if(NULL == gfp)
		return ERR_PTR(-WR_ERR_OPENSESSION);
	session = __get_session(name);
	if(IS_ERR(session) )
		return ERR_PTR(session);
	if(session != NULL)
		return session;
	session = (wr_session_t *)malloc(sizeof(wr_session_t));
	if(NULL == session)
		return ERR_PTR(-WR_NOMEM);
	/*init session member*/
	strcpy(session->name, name);
	strcpy(session->passwd, passwd);
	sprintf(session->session_id, "%ld", time(&now));
	session->last_time = now;
	session->avail_time = now + WR_SESSION_TIMEOUT;
	/*write the session file*/
	fseek(gfp, 0L, SEEK_END);
	session->keyid = ftell(gfp)/sizeof(wr_session_t);
	fwrite(session, sizeof(wr_session_t), 1, gfp);
	fflush(gfp);
	return session;
}

wr_session_t * get_session_keyid(int keyid, char *name, char *passwd)
{
	wr_session_t *session;
	time_t now;
	
	if(NULL == gfp)
		return ERR_PTR(-WR_ERR_OPENSESSION);
	session = __get_session_keyid(keyid);
	if(IS_ERR(session) )
		return ERR_PTR(session);
	if(session != NULL)
		return session;
	session = (wr_session_t *)malloc(sizeof(wr_session_t));
	if(NULL == session)
		return ERR_PTR(-WR_NOMEM);
	/*init session member*/
	strcpy(session->name, name);
	strcpy(session->passwd, passwd);
	sprintf(session->session_id, "%ld", time(&now));
	session->last_time = now;
	session->avail_time = now + WR_SESSION_TIMEOUT;
	/*write the session file*/
	fseek(gfp, 0L, SEEK_END);
	session->keyid = ftell(gfp)/sizeof(wr_session_t);
	fwrite(session, sizeof(wr_session_t), 1, gfp);
	fflush(gfp);
	return session;
}

wr_session_t * update_session(wr_session_t *session)
{
	if(NULL == gfp)
		return ERR_PTR(-WR_ERR_OPENSESSION);
	/*read the session file*/
	fseek(gfp, session->keyid*sizeof(wr_session_t), SEEK_SET);
	fwrite(session, sizeof(wr_session_t), 1, gfp);
	fflush(gfp);
	return session;
}

/*1: alread login; 0: no login , <0: error*/
int islogin_session_checksessionid(char *name, int keyid,  char *sessionid, char *newsessionid)
{
	wr_session_t *session;
	wr_session_t *errsession;
	time_t now;
	
	if(keyid < 0)
		session = 	__get_session(name);
	else
		session = __get_session_keyid(keyid);
	if(IS_ERR(session))
		return PTR_ERR(session);
	if(NULL == session)
		return 0;
	/*first compare the login flag*/
	if(session->flag == WR_SESSION_FLAG_LOGIN)
	{
		time(&now);
		if(strcmp(sessionid, session->session_id))
		{
			free(session);
			return 0;	
		}
		
		if(session->avail_time >= now)/*the session is in avail time and sessionid same*/
		{
			session->last_time = now;
			session->avail_time = now + WR_SESSION_TIMEOUT;
			memset(session->session_id, 0x00, sizeof(session->session_id));
			strncpy(session->session_id, newsessionid, sizeof(session->session_id)-1);
			errsession = update_session(session);
			free(session);
			if(IS_ERR(errsession))
				return PTR_ERR(errsession);
			return 1;
		}
		else/*time out and sessionid same*/
		{
			session->flag = WR_SESSION_FLAG_NOLOGIN;
			session->last_time = now;
			errsession = update_session(session);
			free(session);
			if(IS_ERR(errsession))
				return PTR_ERR(errsession);
			return 0;	
		}
	}
	free(session);
	return 0;
}

/*1: alread login; 0: no login , <0: error*/
int islogin_session_checkpasswd(char *name, int keyid,  char *passwd, char *newsessionid)
{
	wr_session_t *session;
	wr_session_t *errsession;
	time_t now;
	
	if(keyid < 0)
		session = 	__get_session(name);
	else
		session = __get_session_keyid(keyid);
	if(IS_ERR(session))
		return PTR_ERR(session);
	if(NULL == session)
		return 0;
	/*first compare the login flag*/
	if(session->flag == WR_SESSION_FLAG_LOGIN)
	{
		time(&now);
		if(strcmp(passwd, session->passwd))
		{
			free(session);
			return 0;	
		}
		
		if(session->avail_time >= now)/*the session is in avail time and passwd same*/
		{
			session->last_time = now;
			session->avail_time = now + WR_SESSION_TIMEOUT;
			memset(session->session_id, 0x00, sizeof(session->session_id));
			strncpy(session->session_id, newsessionid, sizeof(session->session_id)-1);
			errsession = update_session(session);
			free(session);
			if(IS_ERR(errsession))
				return PTR_ERR(errsession);
			return 1;
		}
		else/*time out and passwd same*/
		{
			session->flag = WR_SESSION_FLAG_NOLOGIN;
			session->last_time = now;
			memset(session->session_id, 0x00, sizeof(session->session_id));
			strncpy(session->session_id, newsessionid, sizeof(session->session_id)-1);
			errsession = update_session(session);
			free(session);
			if(IS_ERR(errsession))
				return PTR_ERR(errsession);
			return 0;	
		}
	}
	free(session);
	return 0;
}

/*<0: error 0: login success*/
int login_session(char *name, int keyid,  char *passwd, char *sessionid)
{
	wr_session_t *session, *errsession;
	time_t now;
	
	if(keyid < 0)
		session = 	get_session(name, passwd);
	else
		session = get_session_keyid(keyid, name, passwd);	
	if(IS_ERR(session))
		return PTR_ERR(session);
	session->flag = WR_SESSION_FLAG_LOGIN;
	time(&now);
	session->last_time = now;
	session->avail_time = now + WR_SESSION_TIMEOUT;
	memset(session->session_id, 0x00, sizeof(session->session_id));
	strncpy(session->session_id, sessionid, sizeof(session->session_id)-1);
	errsession = update_session(session);
	free(session);
	if(IS_ERR(errsession))
		return PTR_ERR(errsession);
	return 0;
}
