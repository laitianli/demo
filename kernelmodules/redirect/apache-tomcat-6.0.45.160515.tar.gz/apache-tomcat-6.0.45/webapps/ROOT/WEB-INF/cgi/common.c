#include <stdlib.h>
#include <string.h>
#include "WRerr.h"
#include "WRbase.h"
#include "WRsession.h"
#include "common.h"

int islogin_user_cookie(char *newsessionid, int nlen)
{
	char *cookie;
	char *temp;
	char sessionid[65];
	char name[33];
	int ret;
	
	cookie = getenv(REQ_HTTP_COOKIE);
	WR_ERR_RET_IF((NULL == cookie || !strcmp(cookie, "")), -1, "get the cookie fail!<br>");
	temp = getvalue4name(cookie, WR_COOKIE_SESSIONID, sessionid, sizeof(sessionid));
	WR_ERR_RET_IF((NULL == temp), -1, "get the session id error from cookie!<br>");
	temp = strchr(sessionid, ':');
	WR_ERR_RET_IF((NULL == temp), -1, "get the name error from session id!<br>");
	memset(name, 0x00, sizeof(name));
	strncpy(name, sessionid, temp-sessionid > 32? 32: temp-sessionid);
	make_sessionid(name, newsessionid, nlen);
	
	ret = open_session();
	if(ret < 0)
	{
		WR_DEBUG("open session fail!\n<br>");
		return ERR_FAILURE;
	}
	ret = islogin_session_checksessionid(name, -1, sessionid, newsessionid);
	close_session();
	return ret;
}
