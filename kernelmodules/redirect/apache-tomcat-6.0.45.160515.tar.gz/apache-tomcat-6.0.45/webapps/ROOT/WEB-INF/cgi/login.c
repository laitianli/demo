#include <stdlib.h>
#include <string.h>
#include "WRerr.h"
#include "WRbase.h"
#include "WRsession.h"
#include "common.h"

#define WR_USERCONF_PATH "./user.conf"

#define WR_REQ_USERNAME "username"
#define WR_REQ_PASSWD "passwd"
#define WR_REQ_KEYID "keyid"


#define WR_CONFILE_USERNAME "username"
#define WR_CONFILE_PASSWD "passwd"
#define WR_LOGIN_ACTION_GETSTAT "getstat"
#define WR_LOGIN_ACTION_LOGIN "login"
#define WR_LOGIN_ACTION_LOGINOUT "loginout"



int main()
{
	int ret;
	char *temp;
	char confinfo[256];
	char confinfo_file[256];
	int outlen;
	char name[33], name_file[33];
	char passwd[33], passwd_file[33];
	char action[33];
	char sessionid[65];
	wr_session_t *session;
	
	FILE *fp;
	
	WR_OPEN_DEBUG();
	WR_DEBUG("start\n");
	
	//memset(confinfo, 0x00, sizeof(confinfo));
	temp = getparams4request(confinfo, 256, &outlen);
	WR_ERR_RET_IF((NULL == temp), -1, "get params from request fail!<br>");
	WR_DEBUG("confinfo = %s\n", confinfo);
	
	/*get action*/
	temp = getvalue4name(confinfo, REQ_ACTION, action, sizeof(action));
	WR_ERR_RET_IF((NULL == temp), -1, "get action from request fail!<br>");
	if(!strcmp(temp, WR_LOGIN_ACTION_LOGIN))
	{
		/*compare the user*/
		memset(name, 0x00, sizeof(name));
		temp = getvalue4name(confinfo, WR_REQ_USERNAME, name, sizeof(name));
		WR_ERR_RET_IF((NULL == temp), -1, "get value of name from request fail!<br>");
		WR_DEBUG("name = %s\n", name);
		
		memset(passwd, 0x00, sizeof(passwd));
		temp = getvalue4name(confinfo, WR_REQ_PASSWD, passwd, sizeof(passwd));
		WR_ERR_RET_IF((NULL == temp), -1, "get value of password from request fail!<br>");
		WR_DEBUG("passwd = %s\n", passwd);
		
		fp = fopen(WR_USERCONF_PATH, "r");
		WR_ERR_RET_IF((NULL == fp), -1, "open the user config file fail!<br>");
		while(!feof(fp) )
		{
			memset(confinfo_file, 0x00, sizeof(confinfo_file));
			temp = fgets(confinfo_file, sizeof(confinfo_file), fp);
			right_trim(confinfo_file, '\n');
			memset(name_file, 0x00, sizeof(name_file));
			temp = getvalue4name(confinfo_file, WR_CONFILE_USERNAME, name_file, sizeof(name_file));
			if(NULL == temp)
			{
				WR_DEBUG("get value of name from config file fail!<br>");
				fclose(fp);
				cgi_error(ERR_FAILURE);
				return -1;
			}
			
			memset(passwd_file, 0x00, sizeof(passwd_file));
			temp = getvalue4name(confinfo_file, WR_CONFILE_PASSWD, passwd_file, sizeof(passwd_file));
			if(NULL == temp)
			{
				WR_DEBUG("get value of password from config file fail!<br>");
				fclose(fp);
				cgi_error(ERR_FAILURE);
				return -1;
			}
			
			WR_DEBUG("name = %s, passwd = %s; name_file = %s, passwd_file=%s;\n", name, passwd, name_file, passwd_file);
			
			if((strlen(name) == strlen(name_file)) && !strcmp(name ,name_file) && (strlen(passwd) == strlen(passwd_file)) && !strcmp(passwd ,passwd_file))
			{
				/* login session */
				ret = open_session();
				if(ret < 0)
				{
					WR_DEBUG("open session fail!\n<br>");
					fclose(fp);
					cgi_error(ERR_FAILURE);
					return -1;
				}
				make_sessionid(name, sessionid, sizeof(sessionid));
				ret = islogin_session_checkpasswd(name, -1, passwd, sessionid);
				if(ret < 0)
				{
					WR_DEBUG("the user login fail,the system busy or have issue!\n");
					fclose(fp);
					close_session();
					cgi_error(ERR_FAILURE);
					return -1;
				}
				else if(ret > 0)
				{
					WR_DEBUG("the user already login, don't repeat login\n");
					fclose(fp);
					close_session();
					printf("Set-Cookie:sessionid=%s\n", sessionid);
					cgi_error(ERR_REPEAT_LOGIN);
					return -1;
				}
				else
				{
					ret = login_session(name, -1, passwd, sessionid);
					if(ret < 0)
					{
						WR_DEBUG("the user login fail,the system busy or have issue!\n");
						fclose(fp);
						close_session();
						cgi_error(ERR_FAILURE);
						return -1;
					}
					else
					{
						WR_DEBUG("the user login success!\n");	
						fclose(fp);
						close_session();
						printf("Set-Cookie:sessionid=%s\n",sessionid);
						cgi_error(ERR_SUCCESS);
						return 0;
					}
				}
			}	
		}
		WR_DEBUG("the no user, login fail!\n");
		cgi_error(ERR_NOTFOUND);
	}
	else if(!strcmp(temp, WR_LOGIN_ACTION_GETSTAT))
	{
		/*get name and passwd from cookie*/
		/*cookie = getenv(REQ_HTTP_COOKIE);
		if(NULL == cookie)
		{
			cgi_error(ERR_COOKIE);
			return -1;	
		}
		WR_DEBUG("this cooke is %s\n\n", cookie);
		temp = getvalue4name(cookie, WR_COOKIE_SESSIONID, sessionid, sizeof(sessionid));
		if(NULL == temp)
		{
			cgi_error(ERR_COOKIE);
			return -1;
		}*/
		/*temp= getvalue4name(cookie, WR_REQ_PASSWD, passwd, sizeof(passwd));
		if(temp == NULL)
		{
			cgi_error(ERR_COOKIE);
			return -1;
		}
		temp = getvalue4name(cookie, WR_REQ_KEYID, strkeyid, sizeof(strkeyid));
		if(NULL != temp)
			keyid = atoi(strkeyid);*/
		/*is user login*/
		ret = islogin_user_cookie(sessionid, sizeof(sessionid));
		if(ret < 0)
		{
			cgi_error(ret);
			return -1;
		}
		else if(ret == 0)
		{
			cgi_error(ERR_NOT_LOGIN);
			return -1;	
		}
		else
		{
			/*return name and sessionid to client by cookie*/
			printf("Set-Cookie:sessionid=%s\n", sessionid);
			cgi_error(ERR_SUCCESS);	
		}
	}
	else if(!strcmp(temp, WR_LOGIN_ACTION_LOGINOUT))
	{
		/*is login?*/
		ret = islogin_user_cookie(sessionid, sizeof(sessionid));
		if(ret < 0)
		{
			WR_DEBUG("system error in the login out!\n");
			cgi_error(ret);
			return -1;
		}
		else if(ret == 0)
		{
			WR_DEBUG("user no login don't login out!\n");
			cgi_error(ERR_NOT_LOGIN);
			return -1;	
		}
		memset(name, 0x00, sizeof(name));
		temp = strchr(sessionid, ':');
		strncpy(name, sessionid, temp-sessionid>32?32:temp-sessionid);
		if(open_session() < 0)
		{
			WR_DEBUG("opensession fail on login out!\n");
			cgi_error(ERR_FAILURE);
			return -1;	
		}
		session = __get_session(name);
		if(NULL == session)
		{
			WR_DEBUG("__get_session fail on login out!\n");
			cgi_error(ERR_FAILURE);
			return -1;	
		}
		WR_DEBUG("__get_session success on login out!\n");
		session->flag = WR_SESSION_FLAG_NOLOGIN;
		update_session(session);
		close_session();
	}
	else
	{
		WR_DEBUG("no support this action!");
		cgi_error(ERR_FAILURE);
		return -1;
	}

	return 0;
}
