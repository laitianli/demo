#ifndef _common_h_
#define _common_h_

extern int islogin_user_cookie(char *newsessionid, int nlen);

#endif
