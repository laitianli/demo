(function($) {
	/* 注册普通消息弹出框 */
	var msgDiv="<div name='alertMsgDialog' title='提示消息' style='display:none;' align='center'>"+
			  "<p id='p_msg' name='p_msg' style='padding-top:20px;'>"+
			    "<div name='message' id='message' style='font-size:12px;word-wrap:break-word;word-break:break-all;white-space:normal;width:325px;overflow:auto;'></div>"+
			  "</p>"+
			"</div>";
	
	/*alert()弹出框*/
	$.alertMsg=function(message,callback){
		if($("div[name=alertMsgDialog]").length==0){
			$("html").append(msgDiv);
		}
		$("div[name=alertMsgDialog] div[name=message]").html(message);
		$("p[name=p_msg]").css('padding-top','20px');
		$("div[name=alertMsgDialog]").attr('align','center');
		
	    $("div[name=alertMsgDialog]").dialog({
	        modal: true,
	        width:358,
	        height:185,
			resizable:false,
			title:"提示消息",
	        buttons: {
	          "确定": function() {
	            $( this ).dialog( "close" );
				if (callback){   
                    callback();   
                }
	           }
	        }
	    }); 
		$(".ui-dialog-titlebar-close").hide();
	};
	
	/*带进度条的弹出框*/
	$.promptMsg=function(message,interval_time,callback){
		if($("div[name=alertMsgDialog]").length==0){
			$("html").append(msgDiv);
		}
		$("div[name=alertMsgDialog] div[name=message]").html(message);
		$("div[name=alertMsgDialog]").append("<br/><div class='promptMsg_graph'><strong id='bar' name='bar' style='width:1%;'>1%</strong></div>");
		$("p[name=p_msg]").css('padding-top','20px');
		$("div[name=alertMsgDialog]").attr('align','center');
		callback_fun = callback;
	    $("div[name=alertMsgDialog]").dialog({
	        modal: true,
	        width:380,
	        height:200,
			resizable:false,
			title:"提示消息",
			buttons: {}
	    }); 
		$(".ui-dialog-titlebar-close").hide();
		bar_times = window.setInterval("go_bar()",interval_time); 
	};		
	
	/*带进度条的弹出框  配置恢复模块*/
	$.promptMsg_stanby=function(message,interval_time,middle,callback){
		if($("div[name=alertMsgDialog]").length==0){
			$("html").append(msgDiv);
		}else{
		    $("div[name=alertMsgDialog]").remove();
			$("html").append(msgDiv);
		}
		$("div[name=alertMsgDialog] div[name=message]").html(message);
		$("div[name=alertMsgDialog]").append("<div class='promptMsg_graph' style='margin-top:20px;'><strong id='bar' name='bar' style='width:1%;'></strong></div>");
		$("p[name=p_msg]").css('padding-top','20px');
		$("div[name=alertMsgDialog]").attr('align','center');
		callback_fun = callback;
		middle_fun = middle;
	    $("div[name=alertMsgDialog]").dialog({
	        modal: true,
	        width:380,
	        height:200,
			resizable:false,
			title:"提示消息",
			buttons: {}
	    }); 
		$(".ui-dialog-titlebar-close").hide();
		bar_times = window.setInterval("go_bar_stanby()",interval_time); 
	};

	/*普通信息的弹出框*/
	$.informationMsg=function(message){
		if($("div[name=alertMsgDialog]").length==0){
			$("html").append(msgDiv);
		}
		$("div[name=alertMsgDialog] div[name=message]").html(message);
        $("p[name=p_msg]").css('padding-top','2px');
		$("div[name=alertMsgDialog]").attr('align','left');
	    $("div[name=alertMsgDialog]").dialog({
			modal: true,
			resizable:false,
			title:"内容详情",
			width:356,
			height:200,
			buttons: {}
	    }); 
		$(".ui-dialog-titlebar-close").show();
	};	
	
	/*confirm()弹出框*/
	$.confirmMsg=function(message,callback){
		if($("div[name=alertMsgDialog]").length==0){
			$("html").append(msgDiv);
		}
		$("div[name=alertMsgDialog] div[name=message]").html(message);
		$("p[name=p_msg]").css('padding-top','20px');
		$("div[name=alertMsgDialog]").attr('align','center');
	    $("div[name=alertMsgDialog]").dialog({
	        modal: true,
	        width:358,
	        height:185,
			resizable:false,
			title:"提示消息",
	        buttons: {
	          "确定": function() {
	              $( this ).dialog( "close" );
				  if(callback){   
                     callback();   
                  }
	          },
			  "取消":function(){
			     $( this ).dialog( "close" );
			  }
	       }
	    }); 
		$(".ui-button").eq(2).focus();  //让取消按钮获得焦点
		$(".ui-dialog-titlebar-close").show();
	};
	
	/*confirm()弹出框   登录检测默认修改密码时用的*/
	$.confirm_pwMsg=function(message,callback){
		if($("div[name=alertMsgDialog]").length==0){
			$("html").append(msgDiv);
		}
		$("div[name=alertMsgDialog] div[name=message]").html(message);
		$("p[name=p_msg]").css('padding-top','20px');
		$("div[name=alertMsgDialog]").attr('align','center');
	    $("div[name=alertMsgDialog]").dialog({
	        modal: true,
	        width:355,
	        height:180,
			resizable:false,
			title:"提示消息",
	        buttons: {
	          "以后再说": function() {
	              $( this ).dialog( "close" );
	          },
			  "立即修改":function(){
			     $( this ).dialog( "close" );
				 if(callback){   
                     callback();   
                 }
			  }
	       }
	    }); 
		$(".ui-button").eq(2).focus();  //让立即修改按钮获得焦点
		$(".ui-dialog-titlebar-close").show();
	};	
})(jQuery);

var bar_times = 0;
var callback_fun;
var middle_fun;

function go_bar(){ 
    var bar_num = parseInt(document.getElementById("bar").style.width) + 1;
	document.getElementById("bar").style.width = bar_num + "%"; 
	document.getElementById("bar").innerHTML = bar_num + "%";
	if(bar_num >= 100){ 
	      window.clearInterval(bar_times); 
		  bar_times = 0;
		  if(callback_fun){   
			 callback_fun();   
		  }
    } 
} 

function go_bar_stanby(){
    var bar_num = parseInt(document.getElementById("bar").style.width) + 1;
	document.getElementById("bar").style.width = bar_num + "%"; 
	document.getElementById("bar").innerHTML = bar_num + "%";
	if(bar_num >= 100){ 
	      window.clearInterval(bar_times); 
		  bar_times = 0;
		  if(callback_fun){   
			 callback_fun();   
		  }
    }else if(bar_num == 80){
		if(middle_fun){
			middle_fun();
		}
	}
}

/*如果进度条走到80%后台还没有返回时，则让其等待*/
function middle_fun_stanby(){
    window.clearInterval(bar_times); 
	bar_times = 0;
}
/*如果在等待时间内，有返回，则重新加载定时器*/
function load_timer_stanby(interval_time){
  // if(bar_times == 0){
       bar_times = window.setInterval("go_bar_stanby()",interval_time); 
  // }
}




