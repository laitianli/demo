var xmit={};

xmit.post = function(arg){
	$.ajax({
		url: arg.url,
		data:arg.data==undefined?'':arg.data,
		async:arg.async==undefined?true:arg.async,
		type: "POST",
		dataType: "html",
		cache: false,
		timeout: arg.timeout == undefined?120000:arg.timeout,
		beforeSend: arg.beforeSend == undefined?xmit.beforeSend_fun:arg.beforeSend,
		success: arg.onrcv,
		error: arg.error == undefined?xmit.error_fun:arg.error,
		complete: arg.complete == undefined?xmit.complete_fun:arg.complete
	});	
}

xmit.error_fun = function(XMLHttpRequest, textStatus, errorThrown){
		alert_msg("提交出错，请稍候再试！");
		$("#b_edit").attr("disabled",false);
		$("#b_refresh").attr("disabled",false); 
		$("#b_enable").attr("disabled",false);
}

xmit.beforeSend_fun = function(){	
	if (window != top && window.parent.Pvs != undefined && typeof(Pvs) != 'undefined') {
		Pvs.showMessage('xmit_loading');
	}
}

xmit.complete_fun = function(){
	if (window != top && window.parent.Pvs != undefined && typeof(Pvs) != 'undefined') {
    	Pvs.hideMessage();
	}
}

