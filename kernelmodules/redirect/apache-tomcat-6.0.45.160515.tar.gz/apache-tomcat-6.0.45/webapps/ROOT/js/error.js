var ERR_SUCCESS = "0";             /*successful operation*/
var ERR_FAILURE = "-1";            /*failure    operation */
var ERR_COOKIE = "-2";             /*cookie timeout, need to login*/
var ERR_LOGINOUT = "-3";           /*login out*/
var ERR_NOT_LOGIN = "-4";          /*user not  login*/
var ERR_REPEAT_LOGIN = "-5";       /*repeat login (a user can login only one place)*/
var ERR_FILE_NOT_EXIST = "-6";     /*restart the web server and need to log in again*/
var ERR_AD_NOT_EXIST = "-7";       /*configuration file is being restored*/
var ERR_NAME_REPEAT = "-8";        /*name repetition*/
var ERR_NOTFOUND = "-9";           /*no record found*/
var ERR_REFERENCE = "-10";         /*is not allowed to delete the reference*/
var ERR_MAX_NUM = "-11";           /*record number up to limit. */
var ERR_KERNEL_FAIL = "-12";       /*to kernel fail  */
var ERR_ENABLE_NOTOP = "-13";      /*can not delete records whose state is enable. */
var ERR_RECORD_EXIST = "-14";      /*record already exists*/
var ERR_TOKEN = "-15";             /*token error*/
var ERR_READ_CONF = "-16";         /*read conf file error*/
var ERR_FOREIGIN_DISABLE = "-17";  /*table's foreign key is disable or delete*/

/*ip*/
var ERR_INVALID_IP = -30;        /*invalid ip addr,eg.256.1.1.1*/
var ERR_INVALID_MASK = -31;      /*invalid mask,eg.255.255.1.0*/
var ERR_INVALID_GATEWAY = -32;   /*invalid gateway addr,eg.256.1.1.1*/
var ERR_LOOP = -33;              /*127 IP network can not be configured*/
var ERR_NET_SEGMENT = -34;       /*network segment can not be configured*/
var ERR_BCAST = -35;             /*broadcast don't permit config*/
var ERR_MCAST = -36;             /*multicast don't permit config*/
var ERR_NOT_INNER_IP = -37;      /*only inner IP allowed. */
var ERR_DIFFER_NET_SEGMENT = -38;/*gateway shoud be in the same network segment with inner IP. */
var ERR_IP_IS_USED = -39;        /*this IP is configured for other function. */
var ERR_SAME_NET = -40;          /*same net range*/

/*basic*/
var ERR_ACTIVEFAL = -60;         /*serial number activation failure*/
var ERR_PORT_IS_USED = -61;      /*mgmt_if: port is used. */
var ERR_PORT_IS_FORBIDDEN = -62; /*mgmt_if: port is forbidden. */
var ERR_SYNC_TIME_FAILURE = -63; /*sync system time failed. */
var ERR_FILE_OVER_SIZE = -64;    /*file size is limitted. */
var ERR_EMAIL_SENDER = -65;      /*email alert sender's format error. */
var ERR_ALERT_IF_DISABLE = -66;  /*alert netif disable or delete*/
var ERR_SMTP_INVALID = -67;      /*smtp invalid. */
var ERR_SMTP_REPEAT = -68;       /*smtp repeat */
var ERR_SMTP_ATTR_NULL = -69;    /* smtp no username and passwd */
var ERR_SMTP_ADD_RULE = -70;
var ERR_ALERT_IF_NULL = -71;
var ERR_ALERT_PARM = -72; 


/*net*/
var ERR_NIC_NOTEXIST = -90;        /* nic is not exist. */
var ERR_NOTSUPPORT_NETMODE = -91;  /* nic not support netmode eg.1000baseT/half */
var ERR_NOTSUPPORT_NEGOMODE = -92; /* nic not support negotiation mode eg.1000baseT/Full */
var	ERR_VLANID_REPEAT = -93;       /* vlanid repeat */
var	ERR_IPNOT_INTHE_RANGE = -94;   /* snat src ip not in the net range*/

/*biz*/
var ERR_PORT_EXIST = -120;        /*service port already exists*/
var	ERR_PORT_INUSE = -121;        /*service is being used, port can not be modified. */
var ERR_NEW_TYPE_INVALID = -122;  /*modifying the used type are not allowed*/
var	ERR_SHUTDOWN_NODE = -123;     /*shutdown a unused node. */
var ERR_PORT_INCONSISTENT = -124; /*nodes' port inconsistent with service's port */
var ERR_ZERO_PORT = -125;         /*it is not allowed that both zero port and nonzero port configured on the same IP address. */
var ERR_MULTI_CONN_PORT = -126;   /* Multiple connection port error(not N+1 or N-1)*/
var ERR_S_ARM = -127;             /* Multiple connection must config persist*/

/*hot_standby*/
var ERR_SYNC_RE_START_STOP = -150; /*re-enable or re-disable hot-standby service. */
var ERR_SYNC_IF_NOT_UP = -151;     /*enable hot-standby service on an interface with physical state is not "UP". */
var ERR_SYNC_STOP_CONFIRM = -152;  /*config hot-standby parameter, with hot-standby enabled. */
var ERR_SYNC_NULL_SETTING = -153;  /*hot-standby setup parameter is not initialled*/

/*user*/
var ERR_OLDPWDERROR = -180;       /*old password input error*/

/* route */
var ERR_SR_CONFLICT = -210;       /* strategy-route's IP addr conflict */
var ERR_SB_BIND = -211;           /* strategy-route already used by biz */
var ERR_NO_UNIQUE = -212;         /* each strategy-route only used a link of protocol(tcp or udp) */
var ERR_MULTI_CONNECT_PORT = -213;/* Mutil connect service port must be 0 */
var ERR_BIZ_CHANGE = -214;        /* work-mode and  refnet_if have changed of biz */

/* dns */
var ERR_DNS_DISABLE = -240;       /* dns disable lead to parse failure */
var ERR_DNS_RESOLVE = -241;       /* dns resolve error */



