/*判断大写状态是否开启功能*/
function oCapsLockTest(pwd_name,tpl_name){
	var inputPWD = document.getElementById(pwd_name);
	var capital = false;
	var capitalTip = {
		elem:document.getElementById(tpl_name),
		toggle:function(s){
			var sy = this.elem.style;
			var d = sy.display;
			if(s){
				sy.display = s;
			}else{
				sy.display = d =='none' ? '' : 'none';
			}
		}
	}
	
	var detectCapsLock = function(event){
		if(capital){return};
		var e = event||window.event;
		var keyCode = e.keyCode||e.which; // 按键的keyCode
		var isShift = e.shiftKey ||(keyCode == 16 ) || false ; // shift键是否按住
		if (((keyCode >= 65 && keyCode <= 90 ) && !isShift) // Caps Lock 打开，且没有按住shift键
			|| ((keyCode >= 97 && keyCode <= 122 ) && isShift)// Caps Lock 打开，且按住shift键
			){
			capitalTip.toggle('block');
			capital=true;
		}else{
			capitalTip.toggle('none');
		}
	}  
	
	inputPWD.onkeypress = detectCapsLock;
	inputPWD.onkeyup=function(event){
		var e = event||window.event;
		if(e.keyCode == 20 && capital){
			capitalTip.toggle();
			return false;
		}
	}	
	inputPWD.onblur=function(){
		$("#"+tpl_name).hide();
		capital = false;
	}
}

function fncKeyStop(evt){
    if(!window.event){
        var keycode = evt.keyCode; 
        var key = String.fromCharCode(keycode).toLowerCase();
        if(evt.ctrlKey && key == "v"){
          evt.preventDefault(); 
          evt.stopPropagation();
        }
    }
}

//键盘只允许输入数字的验证
function key_pass_num(ctrl,e){
	key_pass(ctrl,e,/[0-9a-zA-Z]/);
}
function key_up_num(ctrl,e){
   key_up(ctrl,e,/\D+/g); 
}
//不允许输入中文
function key_pass_nostr(ctrl,e){
    key_pass(ctrl,e,/^[u4E00-u9FA5]+$/);
}
function key_up_nostr(ctrl,e){
   key_up(ctrl,e,/[\u4e00-\u9fa5]/g); 
}
//只允许输入数字和+号
function key_up_num_and(ctrl,e){
	key_up(ctrl,e,/[^\d+]/g); 
}
//只允许输入数字和*号
function key_up_num_xin(ctrl,e){
	key_up(ctrl,e,/[^\d*]/g); 
}
//只允许输入数字和,号
function key_up_num_douhao(ctrl,e){
   key_up(ctrl,e,/[^\d,]/g); 
}

//限制文本框的一些输入
function key_pass(ctrl,e,check_str){
	var keynum;
	var keychar;
	var numcheck = check_str;/*这里为什么要加字母，是因为不加字母在firefox下不可以按键盘上的ctrl+c和ctrl+v进行复制粘贴*/
	if(window.event){ // IE
		keynum = e.keyCode;
	}else if(e.which){  // Netscape/Firefox/Opera
		keynum = e.which;
	}
	keychar = String.fromCharCode(keynum);
	if(numcheck.test(keychar) || keynum == 8 || keynum == undefined || keynum=='undefined'){
	    return true;
	}	
	return false;
}

function key_up(ctrl,e,check_str){
    e=e||event;
	var CaretPos = 0; // IE Support
	if (document.selection) {
		var Sel = document.selection.createRange();
		Sel.moveStart('character', -ctrl.value.length);
		CaretPos = Sel.text.length;
	}else if (ctrl.selectionStart || ctrl.selectionStart == '0'){		
		CaretPos = ctrl.selectionStart;
	}
	
	var value = ctrl.value.replace(check_str, "");
	$(ctrl).val(value);

	if(CaretPos < ctrl.value.length){
		if (ctrl.setSelectionRange) {
			ctrl.focus();
			ctrl.setSelectionRange(CaretPos, CaretPos);
		}else if (ctrl.createTextRange) {
			var range = ctrl.createTextRange();
			range.collapse(true);
			range.moveEnd('character', CaretPos);
			range.moveStart('character', CaretPos);
			range.select();
		}
	}
}

//验证浏览器是否支持cookie的方法
function CookieEnable(){
	var result=0;
	if(navigator.cookiesEnabled){
	   return 1;
	}
	document.cookie = "testcookie=yes; secure;";
	var cookieSet = document.cookie;
	if (cookieSet.indexOf("testcookie=yes") > -1){
		result=1;
	    document.cookie = "";
	}
	return result;
}

//获取cookie
function getCookie(name){
   var strCookie=document.cookie;
   
   var arrCookie=strCookie.split("; ");
   for(var i=0;i<arrCookie.length;i++){
		var arr=arrCookie[i].split("=");
		if(arr[0]==name)
		 return arr[1];
   }
   return "";
}
//清除cookie
function clearCookie(){
	delCookie("sessionid");
  delCookie("formpage");
}      
//设置cookie
function setCookie(name,value,expireHours){
	 var cookieString=name+"="+escape(value);
	 if(expireHours>0){
			var date=new Date();
			date.setTime(date.getTime+expireHours*3600*1000);
			cookieString=cookieString+"; expire="+date.toGMTString();
	 }
	 cookieString=cookieString+"; secure;";
	 document.cookie=cookieString;
}

//删除cookie
function delCookie(name) {
	setCookie(name,'',-1);
}

function change_title(hostname,ip){
    document.title = "PowerAD - "+hostname+" ("+ip+")";
}

