function doInit(){
	//initButton_edit(menuCode_mgmt_if);   //初使化按钮权限	
	//判断此用户是否有启用远程维护的权限
	//if(!check_b_Permision(menuCode_mgmt_if,"-7")){
		//$("input[name=remote_maintain]").attr("disabled","disabled");
	//}
	initTable();	//加载页面内容
}

//管理网口的初化事件
function initTable(){ 
	xmit.post({url:"/cgi-bin/configset.cgi",data:"action=get",onrcv:function(result){
		if(checkErrorInfo(result)){
			var data = eval('('+result+')');
			$("#ratio_type").val(data.ratio_type);
			$("#ratio").val(data.ratio);
			$("#url").val(data.url);
			$("#network").val(data.network);
			$("#availd").val(data.availd);
			if(data.ratio_type != ""){
				$("input[name=ratio_type][value="+data.ratio_type+"]").attr("checked",true);
			}
			if(data.wr_availd != ""){
				$("input[name=availd][value="+data.availd+"]").attr("checked",true);
			}
		}												
	}}); 	
}

//下发按钮事件
function submitSavetoKernel(){
	$("#b_edittokernel").attr("disabled","disabled");	
	xmit.post({url:"/cgi-bin/configset.cgi",data:"action=tokernel&",onrcv:function(result){
		  if(checkErrorInfo(result)){
			//window.parent.window.change_top_title(hostname,ip);
			alert_msg("下发成功！");						
		 }
		 else
		 {
			 alert_msg("下发失败，检查字段是否格式有误！");
		 }
		 $("#b_edittokernel").attr("disabled",false);
	}});
}

//更新按钮事件
function submitCheck(){
	var ratio =$.trim($("#ratio").val());
	var url = $.trim($("#url").val());
	var network = $.trim($("#network").val());
	
	if(ratio == ""){
		alert_msg("请输入重定向频率！",function(){$("#ratio").focus();});
		return false;
	}
	if(!is_number(ratio) || outof(ratio, 0, 1000000000000)){
		alert_msg("重定向频率的取值范围为0～1000000000000！",function(){$("#ratio").focus();});
		return false;
	}	
	$("#ratio").val(ratio);
	
	if(url == ""){
		alert_msg("请输入重定向URL地址！",function(){$("#url").focus();});
		return false;
	}	
	/*if(!check_url(url)){
		alert_msg("请输入合法的URL地址！",function(){$("#url").focus();});
		return false;
	}*/
	$("#url").val(url);
	
	if(network == ""){
		alert_msg("请选择重定向网卡！",function(){$("#network").focus();});
		return false;
	}
	$("#network").val(network);
	$("#b_edit").attr("disabled","disabled");		
	xmit.post({url:"/cgi-bin/configset.cgi",data:"action=save&"+$("#form1").serialize(),onrcv:function(result){
		  if(checkErrorInfo(result)){
			//window.parent.window.change_top_title(hostname,ip);
			alert_msg("更新成功！");						
		 }
		 else
		 {
			 alert_msg("更新失败，检查字段是否格式有误！");
		 }
		 $("#b_edit").attr("disabled",false);
	}});
}
