var Pvs = new Object();	
//var curState = null;
var welcome_page = "sys_overview.html";
var wrconfigset_page = "configset.html"
var support_page = "support.html";
var isIE = (document.all) ? true : false;

$(document).ready(function(){	 
	init_info();	

	/*导航条事件************************************/
	$(".mune_show ").each(function(index) {
		$(this).click(function() {
			var ele = $(this);  
			//获取当前点击的dl，如果是隐藏的就显示，
			var curShowMn = $(".mune_hidden").eq(index);
			if(curShowMn.is(":hidden")){
			   curShowMn.show();
			}else{
			   curShowMn.css("display", "none");
			} 
		});
	});	
	
	$("#img_loginout").hover(function() {
		$("#img_loginout").attr("src","images/exit01.png");							  
    },function(){
		$("#img_loginout").attr("src","images/exit.png");	
    });
	
	$(".sub-menu ul li").hover(function() {
		$(this).css("background-color", "#e3eaf3");   //鼠标移动上去时的背景颜色
	}, function() {
		$(this).css("background-color", "");
	});

	//render_main_menu();   //初使化左边菜单事件
	//refresh
	var currentformpage = getCookie("formpage");
    /*if(!curState){
		load_content("license.html");
	}else */if(currentformpage != 'undefined' && currentformpage != "" && currentformpage != undefined ){	
		var refreshPage = Escape.toXmlAttribute(unescape(currentformpage));
	    load_content(refreshPage);
	}else{
		load_content(welcome_page);
	}	
	
    showScroll();
});	

function showScroll(){
	//首先将#back-to-top隐藏
	$("#back-to-top").hide();
	//当滚动条的位置处于距顶部100像素以下时，跳转链接出现，否则消失
	$(window).scroll(function(){
		if ($(window).scrollTop()>100){
			$("#back-to-top").fadeIn(1500);
		}else{
			$("#back-to-top").fadeOut(1500);
		}
	});
	//当点击跳转链接后，回到页面顶部位置
	$("#back-to-top").click(function(){
		$('body,html').animate({scrollTop:0},1000);
		return false;
	});
}

//提供给系统概览页面用的方法
function quick_link(index){
	var obj_main = $("#mainmenu-"+index);	
	obj_main.show();
	obj_main.find(">dd >ul >li").eq(0).click();
}

function mark_main_menu(obj){	
	$(".current_li").removeClass("current_li");    //去除掉当前选中的事件
	$(obj).parent().parent().parent().show();
	$(obj).addClass("current_li");	
}

//初使化左边二级菜单的点击事件 
function render_main_menu(){
  	$(".mune_hidden > dd > ul > li").click(function(){	
		scrollToTop();
	    init_main_menu(this);   //设置三级菜单项
	    do_open_first();   //默认打开第一个三级菜单项
		return false;
	});	
} 

function welcome(){
   load_content(welcome_page);
   setCookie("formpage",welcome_page);
   $("#alarm_module").hide();
}

function wrconfigset(){
   load_content(wrconfigset_page);
   setCookie("formpage",wrconfigset_page);
   //$("#alarm_module").hide();
}

function init_sys_overview(){
	 $("#pagemenu").html(" <li id='pagemenu-sys_overview'><a class='sidebar_a' onclick='welcome()' target='contentFrame'><strong class='sidebar_strong '>系统概览</strong></a></li><li id='pagemenu-support'><a class='sidebar_a' onclick='load_content(\""+support_page+"\")' target='contentFrame'><strong class='sidebar_strong'>技术支持</strong></a></li>");	
	setCur_wz("系统概览","","系统概览","");	 
}

function init_main_menu(obj){
	 	var li_id = $(obj).attr('id');   //获取li的id属性
		var obj_a = $(obj).find("a");
		
		if(obj_a.length == 0){
			$(".current_li").removeClass("current_li");    //去除掉当前选中的事件
			init_sys_overview(); 
		    return;
		}
		
		var a_id = obj_a.attr('id');     //获取li>a的id属性
		var a_href = obj_a.attr("href");  //获取li>a的href属性

		mark_main_menu(obj);  //设置当前选中的一级菜单与二级菜单 
		var info = "";
		
    	if(a_href != "#"){	
		    info = "<li id='pagemenu-"+a_href.replace(".html","")+"'><a class='sidebar_a' onclick='load_content(\""+a_href+"\")' target='contentFrame'><strong class='sidebar_strong'>"+obj_a.html()+"</strong></a></li>";
		}else{
			xmit.post({url:"/frame_main.fcgi?action=getpagemenu",async:false,data:{pid:a_id},onrcv:function(result){
			   if(checkErrorInfo(result)){
					 var data = eval('('+result+')');
					 var tmp = data["module_c_c"];
					 if(tmp.length > 0){						 
						 for(var i=0; i<tmp.length; i++){
							 info += "<li id='pagemenu-"+tmp[i].src.replace(".html","")+"'><a id='"+tmp[i].src.replace(".html","")+"' class='sidebar_a' onclick='load_content(\""+tmp[i].src+"\")' target='contentFrame'><strong class='sidebar_strong'>"+tmp[i].name+"</strong></a></li>";
						 }												
					 }				
			   }
			}});
		}	
					
		/*if(a_id+"-2" == menuCode_email_alert){
			$("#alarm_module").show();
		}else{
			$("#alarm_module").hide();
		}*/
		
		$("#pagemenu").html(info);	  //设置三级菜单
		var one_wz = $(obj).parent().parent().parent().prev().find("dd").html();   //设置当前位置:一级
		var two_wz = " <a class='cur_wz_a' onclick='do_open_first()' target='contentFrame'>"+$(obj).find("a").html()+"</a>";        //设置当前位置:二级
		setCur_wz(one_wz,two_wz,"","");	 
}

function do_open_first(){
     $("#pagemenu > li > a.current_a").removeClass("current_a");
	 $("#pagemenu > li > a > strong.current_strong").removeClass("current_strong");
	 $("#pagemenu li:first-child a").addClass("current_a");
	 $("#pagemenu li:first-child a > strong").addClass("current_strong");
	 $("#pagemenu li:first-child a").click(); 		    //设置三级菜单的第一个菜单默认选中
}

function setCur_wz(one_wz,two_wz,three_wz,four_wz){
    if(one_wz != null){
		$("#trail_span1").html(one_wz);
	}
	if(two_wz != null){
		if(two_wz != ""){
			two_wz = " > "+two_wz;
		} 
		$("#trail_span2").html(two_wz);
	}
	if(three_wz != null){
		if(three_wz != ""){
		   three_wz = " > "+three_wz;
		}
		$("#trail_span3").html(three_wz);
	}
	if(four_wz != null){
		if(four_wz != ""){
		   four_wz = " > "+four_wz;
		}
	    $("#trail_span4").html(four_wz);
	}
}

function loadMenues(){
    var contenthref = frames['contentFrame'].location.href;
	var page = contenthref.substring(contenthref.lastIndexOf("/")+1);
	
	var currentformpage = getCookie("formpage");
	if(currentformpage != page && page != welcome_page){
       setCookie("formpage",page);
	}	

	var end = contenthref.indexOf('?');	
	if(end != -1){
	   page = contenthref.substring(contenthref.lastIndexOf("/")+1,end);
	}
	var op = null;
	if(page.indexOf('add_') != -1 || page.indexOf('edit_') != -1){
	     op = cur_wz_edit;
	}	

    page = page.replace("add_","").replace("edit_","");
	var mainMenuObject = null;
	var pageMenuObject = $("#pagemenu-"+page.replace(".html",""));
	if(pageMenuObject.length > 0){
		 $("#pagemenu > li > a.current_a").removeClass("current_a");
		 $("#pagemenu > li > a > strong.current_strong").removeClass("current_strong");
	
		 $(pageMenuObject).find("a").addClass("current_a");
		 $(pageMenuObject).find("a > strong").addClass("current_strong");
         if($("#pagemenu").find("li").size() > 1){
			var three_wz = "<a class='cur_wz_a' onclick='"+$(pageMenuObject).find("a").attr("onclick")+"' target='contentFrame'>"+$(pageMenuObject).find("a > strong").html()+"</a>";//设置当前位置:三级
         	setCur_wz(null,null,three_wz,null);
		 }
	}else{
		for(var i=0; i<TOPNAV.items.length; i++){
			if(page==TOPNAV.items[i].page){
				mainMenuObject = $("#mainmenu-"+TOPNAV.items[i].label);
				init_main_menu(mainMenuObject);
				pageMenuObject = $("#pagemenu-"+TOPNAV.items[i].label);
				$(pageMenuObject).find("a").addClass("current_a");
				$(pageMenuObject).find("a > strong").addClass("current_strong");
		       // setCur_wz(null,null,$(pageMenuObject).find("a > strong").html(),op);
				setCur_wz(null,null,null,op);
				return;
			}
		}
		
		for(var i=0; i<TOPNAV.items.length; i++){
			var SUBNAV = eval(TOPNAV.items[i].nav);
			if(SUBNAV==undefined) continue;
			for(var b=0; b<SUBNAV.items.length; b++){
				if(page==SUBNAV.items[b].page){					
					mainMenuObject = $("#mainmenu-"+TOPNAV.items[i].label);
					init_main_menu(mainMenuObject);
					pageMenuObject = $("#pagemenu-"+SUBNAV.items[b].label);
					$(pageMenuObject).find("a").addClass("current_a");
				    $(pageMenuObject).find("a > strong").addClass("current_strong");
					var three_wz = "<a class='cur_wz_a' onclick='"+$(pageMenuObject).find("a").attr("onclick")+"' target='contentFrame'>"+$(pageMenuObject).find("a > strong").html()+"</a>";//设置当前位置:三级
                    setCur_wz(null,null,three_wz,op);
					break;
				}
			}
		}
        
	}
}
/*加载帮助中心*/
function loadHelp() {
	jQuery(function(){
		var helpFrameObject = frames['helpFrame'];
		var contenthref = frames['contentFrame'].location.href;
		var end = contenthref.indexOf('?');
		var url = "";
		if(end == -1){
		   url = contenthref.substring(contenthref.lastIndexOf("/")+1);
		}else{
		   url = contenthref.substring(contenthref.lastIndexOf("/")+1,end);
		}

        if(url == welcome_page || url == support_page){
		     url = "help.html";
		}		
		helpFrameObject.location.replace("help/"+url);
		return false;
	});
}

function load_content(href) {
	jQuery(function() {
		$('#contentFrame').attr('src',href);
	});
	//////////////////////
	if("mail_alert.html" == href || "sms_alert.html" == href){
		$("#alarm_module").show();
	}else{
		$("#alarm_module").hide();
	}
	/////////////////////
	return false;
}

function show_panel(id){
	$('.left-sidebar > ul > li > a.current_a').removeClass('current_a');
	$('.left-sidebar > ul > li > a > strong.current_strong').removeClass('current_strong');

	$("#"+id).find("a").addClass("current_a");
	$("#"+id).find("a > strong").addClass("current_strong");
	
	var content= id+'_panel';
	$('#'+content).show();
}

function init_info(){
	 //xmit.post({url:"/frame_main.fcgi?action=showleft",onrcv:show_left,async:false});
	 xmit.post({url:"/frame_main.cgi?action=showtop",onrcv:function(result){
		if(checkErrorInfo(result)){			      
			var data = eval('('+result+')');			
			$("#name").html(html_substr(data.name,20));
		}												
	  }}); 	
}

//初使化左边菜单方法
function show_left(result){   
	if(checkErrorInfo(result)){
		 var strarray = result.split('|');	     
		 if(strarray.length == 2){
			 var info = "";
			 if(strarray[0] == "false"){
				info += "<dl class='mune_show'><dt><img src='images/bas-con.png' /></dt><dd class='bott-line'>基本配置</dd></dl>"	;
				info += "<dl class='mune_hidden' id='mainmenu-basic'><dd class='sub-menu'><ul><li id='mainmenu-license'><a href='license.html' target='contentFrame'>系统激活</a></li>";
				info += "</ul></dd></dl>";	
				info += "<dl class='mune_show'></dl> ";
				$("div[name='left_info']").append(info);
				curState = false;
			 }else if(strarray[0] == "true"){	
				if(strarray[1] != "" && strarray[1] != 'undefined' && strarray[1] != undefined){
					 var data = eval('('+strarray[1]+')');
					 var tmp = data["permission"];
					 for(var i=0; i<tmp.length; i++){
						  info += "<dl class='mune_show'><dt><img src='images/"+tmp[i].image+"'/></dt><dd class='bott-line'>"+tmp[i].name+"</dd></dl><dl class='mune_hidden' id='mainmenu-"+tmp[i].id+"'><dd class='sub-menu'><ul>";
						  
						  var module_c = tmp[i].module_c;
						  for(var j=0;j<module_c.length;j++){
						   info += "<li id='mainmenu-"+module_c[j].id+"'><a id='"+module_c[j].privelege+"' href='#'>"+module_c[j].name+"</a></li>";
						  }						  
						  info += " </ul></dd></dl>"; 
					 }
				 }else{
				    info += "<dl class='mune_show'><dt><img src='images/con-par.png' /></dt><dd class='bott-line'>控制参数</dd></dl>"	;							 
					info += "<dl class='mune_hidden' id='mainmenu-conparam'><dd class='sub-menu'><ul><li id='mainmenu-timeout'><a href='timeout.html' target='contentFrame'>连接超时时间</a></li>";
					info += "<li id='mainmenu-controlparameter'><a href='controlparameter.html' target='contentFrame'>控制参数配置</a></li></ul></dd></dl>";					
				 }
				 info += "<dl class='mune_show'></dl> ";
				 $("div[name='left_info']").append(info);	
				 curState = true;
			 }
		 }else{
				alert_msg("result:"+result);
		 }
	}		
}

function initContent(){
    resizeFrameHeight("contentFrame",500);
	$('#contentFrame').css('visibility','visible');
	try {
		frames['contentFrame'].Pvs.initContentEvents();
		$('#contentFrame').css('overflow-y','hidden');
	}
	catch(e) {
		$('#contentFrame').css('overflow-y','auto');
	}
	loadMenues();
	loadHelp();  //实例化帮助信息
	
	if(!$('#messagetype').hasClass('xmit_loading')){
		hideMessage();
	}
}

function initContentBeforeUnLoad() {
    jQuery(function() {
        showMessage('loading');
    });
} 

function initContentUnLoad() {
    jQuery(function() {
        // Hide Content (fixes white flash)
        $('#contentFrame').css('height','0px');
    });
}

window.onload = function(e) { 
    // Check for Firebug add-on (Firefox)
	if (window.console && window.console.firebug) {
		alert_msg("For the best performance, please disable Firebug while using the PWD configuration utility.");
	}   
};

window.onbeforeunload = function(e) {
	window.onerror = function(e){
		return true;
    };
};

//显示loading......
function showMessage(type) {
	jQuery(function() {	
		var messageObject = $('#load_message');
		$("#messagetype").addClass(type);
		//if (isIE) {  
			messageObject.show();
			$("#loading-mask").show();
		//}
		//else {
		//	messageObject.fadeIn('fast');
		//	$("#loading-mask").fadeIn('fast');
		//}		
	});
	return false;
}
//隐藏loading.....
function hideMessage() {
	jQuery(function() {
		$("#messagetype").removeClass('xmit_loading');
		if (isIE) {
			$('#load_message').hide();
			$("#loading-mask").hide();
		}
		else {
			$('#load_message').fadeOut('fast');
			$("#loading-mask").fadeOut('fast');
		}		
	});
	return false;
}

/*隐藏左窗口的事件*/
function switchSysBar($tdObj){ 
	var ssrc=$tdObj.find(".str-hj ").html();
	if(ssrc=="收起"){
		$tdObj.find(".str-hj ").html("展开");
		$tdObj.find(".str-hj0").html("&gt;&gt;");
		$tdObj.attr('title','展开边栏');
		$("#mainbody").removeClass("bodyclass");
		$("#frmTitle").hide();	
	}else{ 
		$tdObj.find(".str-hj ").html("收起");
		$tdObj.find(".str-hj0").html("&lt;&lt;");
		$tdObj.attr('title','收起边栏');
		$("#mainbody").addClass("bodyclass");
		$("#frmTitle").show();
	} 
}
/*调整iframe的调度*/
function resizeFrameHeight(frameNameOrID,fallbackHeightValue) {
	try {
		try {				
			var newHeight = document.getElementById(frameNameOrID).contentWindow.document.body.scrollHeight;
			if (newHeight != 0)	document.getElementById(frameNameOrID).style.height = newHeight + 'px';
		}catch(e) {
			var newHeight = frames[frameNameOrID].window.document.body.scrollHeight;
			if (newHeight != 0)	document.getElementsByTagName('iframe')[frameNameOrID].style.height = newHeight + 'px'
		}
	}catch(e) {
		if (fallbackHeightValue) {
			try {
				if (newHeight != 0)	document.getElementById(frameNameOrID).style.height = fallbackHeightValue + 'px';
			}catch(e) {
				if (newHeight != 0)	document.getElementsByTagName('iframe')[frameNameOrID].style.height = fallbackHeightValue + 'px';
			}
		}
	}
}

function scrollToTop() {
	var x1 = x2 = x3 = 0;
	var y1 = y2 = y3 = 0;
	if (document.documentElement) {
		x1 = document.documentElement.scrollLeft || 0;
		y1 = document.documentElement.scrollTop || 0;
	}
	if (document.body) {
		x2 = document.body.scrollLeft || 0;
		y2 = document.body.scrollTop || 0;
	}
	x3 = window.scrollX || 0;
	y3 = window.scrollY || 0;
	var x = Math.max(x1, Math.max(x2, x3));
	var y = Math.max(y1, Math.max(y2, y3));
	window.scrollTo(Math.floor(x / 2), Math.floor(y / 2));
	if (x > 0 || y > 0) {
		window.setTimeout("scrollToTop()", 35);
	}
}

Escape = new Escape();
function Escape() {
	this.toXmlAttribute = function(value) {
		if (!value) {
			return null;
		}
		var output = value;
		output = output.replace(/</g, "&#60;");
		output = output.replace(/\"/g, "&#34;");
		output = output.replace(/'/g, "&#39;");
		output = output.replace(/\r\n/g, "&#10;");
		output = output.replace(/\n/g, "&#10;");
		//output = output.replace(/&/g, "&#38;");
		return output;
	};
	this.fromXmlAttribute = function(value) {
		if (!value) {
			return null;
		}
		var output = value;
		//output = output.replace(/&#38;/g, "&");
		output = output.replace(/&#10;/g, "\n");
		output = output.replace(/&#39;/g, "'");
		output = output.replace(/&#34;/g, "\"");
		output = output.replace(/&#60;/g, "<");
		return output;
	};
}