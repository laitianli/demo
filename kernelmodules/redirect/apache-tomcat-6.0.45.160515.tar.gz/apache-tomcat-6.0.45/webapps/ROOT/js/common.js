$(document).ready(function() {						   
	$(".large").each(function(){
		var name =$(this).attr("id")+"_msg"; 
		$(this)	.focus(function(){                            
			   $("#"+name).show();
		})
		.blur(function(){
			   $("#"+name).hide();
		})
	});	
	deletebottomline();
});

function deletebottomline(){
   $('.right-oth-alltab').each(function(){$(this).find('tr:last').addClass('tr_last');}); 
}

//定义模块名称
var menuCode_mgmt_if = "1001-1-1";
var menuCode_sys_time = "1001-1-2";
var menuCode_stanby = "1001-1-3";
var menuCode_reboot = "1001-1-4";
var menuCode_license = "1001-2-1";
var menuCode_smtp = "1001-3-1";
var menuCode_email_alert = "1001-3-2";
var menuCode_sms_alert = "1001-3-3";

var menuCode_nic = "1002-1-1";
var menuCode_net_if = "1002-1-2";
var menuCode_vlan = "1002-1-3";
var menuCode_dns = "1002-2-1";
var menuCode_snat = "1002-3-1";

var menuCode_service = "1003-1-1";
var menuCode_persist = "1003-2-1";
var menuCode_node_mon = "1003-3-1";
var menuCode_node = "1003-4-1";
var menuCode_vs = "1003-5-1";

var menuCode_strategy_bind = "1004-1-1";
var menuCode_strategy_route = "1004-1-2";

var menuCode_set_up = "1005-1-1";
var menuCode_syncs = "1005-2-1";
var menuCode_hand_sync = "1005-2-2";
  
var menuCode_system_state = "1006-1-1";
var menuCode_cpu = "1006-1-2";
var menuCode_memory = "1006-1-3";   
var menuCode_throughput = "1006-1-4";
var menuCode_link_count = "1006-1-5";
var menuCode_node_state = "1006-2-1";
var menuCode_vs_state = "1006-3-1";
var menuCode_m_log = "1006-4-1";
var menuCode_s_log = "1006-4-2";

var menuCode_user = "1007-1-1";
var menuCode_role = "1007-2-1";

//验证按钮权限的方法
function check_b_Permision(menuCode,button){
   var p =base64_decode(getCookie("button"));
   if(p == 'undefined' || p == "" || p == undefined || p == "all"){
       return true;   
   }else{
	   var list = p.split(',');
	   for(var i=0;i<list.length;i++){
		  if(menuCode+button == list[i]){
			   return true;
		  }
	   }
	   return false;
   }  
}

function initButton(menuCode_name){
   if(!check_b_Permision(menuCode_name,"-2")){
	  $("#b_add").css("display","none");
   }
   if(!check_b_Permision(menuCode_name,"-4")){
	  $("#b_del").css("display","none");
   }
   if(!check_b_Permision(menuCode_name,"-5")){
	  $("#b_enable").css("display","none");
   }
   if(!check_b_Permision(menuCode_name,"-6")){
	  $("#b_unenable").css("display","none");
   }
   if(!check_b_Permision(menuCode_name,"-7")){
	  $("#b_quit").css("display","none");
   }
   if(!check_b_Permision(menuCode_name,"-8")){
	  $("#b_clear").css("display","none");
   }
}

function initButton_edit(menuCode_name){
	if(!check_b_Permision(menuCode_name,"-3")){
		$("#b_edit").attr("disabled","disabled");
	}	
}
/* 判断一个utf-8字符串所占的长度*/
function check_length(str){
	var cnt = 0;
	for( i=0; i<str.length; i++){
		var value = str.charCodeAt(i);
		if( value < 0x080){
			cnt += 1;
		}else if( value < 0x0800){
			cnt += 2;
		}else if( value < 0x10000 ){
			cnt += 3;
		}else{
			cnt += 4;
		}
	}
	return cnt;
}

function replaceAll(src,oldStr,newStr){  
	return src.replace(new RegExp(oldStr, "g"), newStr);  
} 
function htmlEncode(str){
	str = replaceAll(str," ","&nbsp;");
	return str;
}
function html_substr(str,len){
	var strinfo = "";
	if(str.length > len){
	  strinfo = str.substr(0,len)+"...";
	}else{
	  strinfo = str;
	}
	return strinfo;
}

/** 
 * js截取字符串，中英文都能用 
 * @param str：需要截取的字符串 
 * @param len: 需要截取的长度 
 */  
function html_substr_new(str,len){  
	var str_length = 0;  
	str_cut = new String();  
	var str_len = str.length;  
	for(var i = 0;i<str_len;i++){  
		a = str.charAt(i);  
		str_length++;
		/*在goole下空格显示的要比其它浏览器宽一些*/
		if(escape(a).length > 4 || (escape(a) == '%20' && navigator.userAgent.indexOf("Chrome")!=-1)){  			
			str_length++;  //中文字符的长度经编码之后大于4  
		}  
		str_cut = str_cut.concat(a);  
		if(str_length>=len){  
			str_cut = str_cut.concat("...");  
			return str_cut;  
		}  
	}  
	return  str;   
}

//去掉前后空格
function trim(str){
    return str.replace(/(^\s*)|(\s*$)/g,'');
}

//去掉ip第一位前面的0
function replace_ip(ip){
	var IPArray = ip.split('.');
	for(var i=0;i<IPArray.length;i++){
	    var num = IPArray[i];
		if(num == '000' || num == '00'){
			IPArray[i] = 0;
		}else if(num.length > 1){
			IPArray[i] = num.replace(/\b(0+)/gi,"");	
		}
	}
	return IPArray.join('.');
}

//不能包含& | " ' , ? : % < > / \ 特殊字符
function check_name(str){	 
	if(""==str || null == str){
		return true;
	}
	var reg = /^[^\\%,:&\'\?\/\<\>\|\"`]+$/;
	return reg.test(str);	
}
//只允许输入字母，数字，下划线，且长度是1-53个字符的正则表达式(用户名)
function check_user_name(str){
	var reg = /^[a-zA-Z0-9\_]{1,}$/;
	return reg.test(str);
}
//判断是否是数字
function is_number(strInteger){     
	var newPar = /^([1-9]\d*|[0]{1,1})$/ ;
	return newPar.test(strInteger);     
} 
//判断数值是否超出指定大小范围
function outof(value,minv,maxv){
	var m = 0;
	if(typeof(value) == 'string'){
		m = parseInt(value,10);
	}else{
		m = value;
	}
	if(m < minv || m > maxv){
	   return true;
	}
	return false;
}

//验证密码(您的密码过于简单，请不要使用纯数字、纯字母或连续3个相同字符)
function check_pwd(str){
	if(!str || /^[0-9]+$/.test(str) || /^[A-Za-z]+$/.test(str)){
	   return false;
	}
	var re = /(.)*(.)\2{2}.*/g;	
	if(re.test(str)){// 在字符串 s 中查找匹配。
	   return false;
	}
	return true;
}
//验证电话号码
function check_phone(str){
	var reg = /^\+?\d+$/;
	return reg.test(str);
}

//检测域名
function checkdomain(urlString){
	var reg = /^(?:(?!-)(?:[a-z0-9-\u4e00-\u9fa5]*)(?:[a-z0-9\u4e00-\u9fa5](?!-))(?:\.(?!-)))+[a-z\u4e00-\u9fa5]{2,6}$/;
	return reg.test(urlString);   
}
//检测邮箱
function check_email(mail){  
   var pattern = /^(?!.*?-@)(?!.*?\.\.)(?!.*?__)(?!.*?--)(?![._-])(?!.*?_@)[A-Z0-9._-]+(?!-._)@(?![._@%+-])(?:[\u4e00-\u9af5\w-]*[\u4e00-\u9af5A-Z\d]+\.)+[\u4e00-\u9af5A-Z]{2,6}$/im;
    return pattern.test(mail) ;
}
//检测URL
function IsURL (str_url) {
    var strRegex = '^((https|http|ftp|rtsp|mms)?://)'
	+ '?(([0-9a-z_!~*\'().&=+$%-]+: )?[0-9a-z_!~*\'().&=+$%-]+@)?' //ftp的user@
	+ '(([0-9]{1,3}.){3}[0-9]{1,3}' // IP形式的URL- 199.194.52.184
	+ '|' // 允许IP和DOMAIN（域名）
	+ '([0-9a-z_!~*\'()-]+.)*' // 域名- www.
	+ '([0-9a-z][0-9a-z-]{0,61})?[0-9a-z].' // 二级域名
	+ '[a-z]{2,6})' // first level domain- .com or .museum
	+ '(:[0-9]{1,4})?' // 端口- :80
	+ '((/?)|' // a slash isn't required if there is no file name
	+ '(/[0-9a-z_!~*\'().;?:@&=+$,%#-]+)+/?)$';
	var re=new RegExp(strRegex);
	if (re.test(str_url)){
		return true;
	}else {
		return false;
	}
} 

/*检查是否合法的IPv4地址,不允许其为空*/
function check_ip_base(ip){
	if(ip == ""){
		return false;
	}
	if(ip=="0.0.0.0"){
		return true;
	}
	return check_ipv4(ip);
}
/*检查是否合法的IPv4地址，只检查格式*/
function check_ipv4(ip){
	var regm = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/;
	return regm.test(ip);
}

//检查互联网IP
function check_inet_ip(ip){
	if(!check_ip_base(ip))
		return false;
	var arr = ip.split(".");
	var first_byte = Number(arr[0]);
	var second_byte = Number(arr[1]);
	if(first_byte == 0 || first_byte ==127 ||first_byte >223)//去掉保留IP和组播IP以及E类IP
		return false;
	if(first_byte == 10)
		return false;
	if(first_byte == 172){
		if(second_byte >=16 && second_byte <= 31){
			return false;
		}
	}
	if(first_byte == 192){
		if(second_byte == 168)
			return false;
	}
	return true;
}

//检测snat的IP  
function check_snat_ip(ip){
    var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
    if(!IPPattern.test(ip))return false;
	
	var IPArray = ip.split('.');
    /* 检查域值 */    
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
    /* 每个域值范围0-255 */
    if ( ip1<0 || ip1>255 || ip2<0 || ip2>255 || ip3<0 || ip3>255 || ip4<0 || ip4>255 ){
       return false;
    }
	return true;
}
//检测子网
function check_net(net){
    var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
    if(!IPPattern.test(net))return false;
	
	var IPArray = net.split('.');
    /* 检查域值 */    
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
    /* 每个域值范围0-255 */
    if ( ip1<0 || ip1>255 || ip2<0 || ip2>255 || ip3<0 || ip3>255 || ip4<0 || ip4>255 ){
       return false;
    }
	if(ip1==0 && ip2==0 && ip3==0 && ip4==0) {
	   return false;
	}
	return true;
}

//检测dns的ip
function check_dns_ip(ip){
    var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
    if(!IPPattern.test(ip))return false;
	
	var IPArray = ip.split('.');	
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
	
	if(ip1 == 0 || ip1 > 223 || ip2 > 255 ||  ip3 > 255 ||  ip4 > 255){
	    return false;	
	}
	return true;
}

//检测ip
function check_ip(ip){
    var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
    if(!IPPattern.test(ip))return false;
	
	var IPArray = ip.split('.');	
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
	
	if(ip1 == 0 || ip1 == 127 || ip1 > 223 ||  ip2 > 255 ||  ip3 > 255 ||  ip4 > 255){
	    return false;	
	}
	return true;
}
//检测多播ip
function check_Multicast_ip(ip){
    var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
    if(!IPPattern.test(ip))return false;
	
	var IPArray = ip.split('.');	
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
	
	if(ip1 > 240){
	    return false;	
	}
	if((ip1 > 223) && (ip2 < 0 || ip2 > 255 || ip3 < 0 || ip3 > 255 || ip4 < 0 || ip4 > 255)){
	    return false;	
	}	
	if((ip1 <= 223) && (ip1 == 0 || ip1 == 127 || ip2 == 0 || ip2 >= 255 || ip3 == 0 || ip3 >= 255 || ip4 == 0 || ip4 >= 255)){
	    return false;	
	}
	return true;
}

/*检测有效的ip*/
function check_invalid_ip(ip){	
	var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
    if(!IPPattern.test(ip))return false;
	
	var IPArray = ip.split('.');	
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
	
	if(ip1 == 0 || ip1 == 127 || ip1 > 223 ||  ip2 > 255 ||  ip3 > 255 ||  ip4 > 255){
	    return false;	
	}
	
   	var ip_type = check_ip_type(ip);
	if((ip_type == 'A' && ((ip2 == 0 && ip3 == 0 && ip4 == 0)|| (ip2 == 255 && ip3 == 255 && ip4 == 255)))||
	   (ip_type == 'B' && ((ip3 == 0 && ip4 == 0) || (ip3 == 255 && ip4 == 255)))||
	   (ip_type == 'C' && (ip4 == 0 || ip4 == 255))    
	){
	    return false;
	}
	return true;
}

/*两个ip是否在同一网段*/
/* IP地址划分: 
* A类地址：1.0.0.1～126.255.255.254     A类网络的子网掩码为255.0.0.0 
* B类地址：128.0.0.1～191.255.255.254   B类网络的子网掩码为255.255.0.0
* C类地址：192.0.0.1～223.255.255.254   C类网络的子网掩码为255.255.255.0
* D类地址：224.0.0.1～239.255.255.254   缺省情况子网掩码为255.255.255.0 */
function check_same_netmask(ip_a,ip_b){
	var ip_a_type = check_ip_type(ip_a);
	var ip_b_type = check_ip_type(ip_b);
	
	if(ip_a_type != ip_b_type){
	     return false;
	}
	
	var mask = "255.255.255.0";
	if(ip_a_type == 'A'){
	    mask = "255.0.0.0";
	}else if(ip_a_type == 'B'){
	    mask = "255.255.0.0";
	}
	
	ip_a = ip_a.split('.');
	ip_b = ip_b.split('.');
	mask = mask.split('.');
	var res1 = [],res2 = []; 
	
	for (var i = 0; i < 4; i++){ 
		res1.push(parseInt(ip_a[i]) & parseInt(mask[i]));
		res2.push(parseInt(ip_b[i]) & parseInt(mask[i]));
	}
	 
	if(res1.join(".") != res2.join(".")){ 
	    return false;
	}
    return true;
}

function check_ip_type(ip){
   	var IPArray = ip.split('.');	
    var ip1 = parseInt(IPArray[0]);
	
	if(ip1 >= 192 && ip1 <= 223){
	    return 'C';
	}else if(ip1 >= 128 && ip1 <= 191){
		return 'B';
	}else if(ip1 >= 1 && ip1 <= 126){
	    return 'A';
	}else{
	    return 'O';
	}
}

//检测ip范围
function check_ip_range(startip,endip){
	var s_arry = startip.split('.');
	var e_arry = endip.split('.');
	
	for (var i = 0; i < 4; i++){ 	    
        if (Number(s_arry[i]) < Number(e_arry[i])){  
			return true;  
		}else if(Number(s_arry[i]) > Number(e_arry[i])){
			return false;
		}
    }  
    return true;     
}
//检测IP+MASK是否匹配
function ip_mask_match(ip,mask){
	var IPArray = ip.split('.');	
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
	
	/*var ipn = ip2long(ip);
	var mskn = ip2long(create_mask(mask,"v4"));	
	//主机部分全部为0则不正确。
	if((ipn&mskn) == ipn){
		return false;
	}*/
	
	/* Class A ,B ,C*/
	if ((ip1 >= 1 && ip1 <= 126 && mask < 8)||(ip1 >= 128 && ip1 <= 191 && mask < 16)||(ip1 >= 192 && ip1 <= 223 && mask < 24)){	
        return false;
	}
    return true;
}

//检测掩码有效性的方法
function check_mask(MaskStr){
    /* 有效性校验 */
    var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
    if(!IPPattern.test(MaskStr))return false;
	
	var IPArray = MaskStr.split('.');
    /* 检查域值 */    
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);
    /* 每个域值范围0-255 */
    if ( ip1<0 || ip1>255 || ip2<0 || ip2>255 || ip3<0 || ip3>255 || ip4<0 || ip4>255 ){
       return false;
    }
    /* 检查二进制值是否合法   拼接二进制字符串*/
    var ip_binary = _checkIput_fomartIP(ip1) + _checkIput_fomartIP(ip2) + _checkIput_fomartIP(ip3) + _checkIput_fomartIP(ip4);

    if(-1 != ip_binary.indexOf("01")){
        return false;
    }
    return true;
}
/**
* 函数名：   _checkIput_fomartIP
* 函数功能： 返回传入参数对应的8位二进制值
* 传入参数： ip:点分十进制的值(0~255),int类型的值，
* 返回值:    ip对应的二进制值(如：传入255，返回11111111;传入1,返回00000001)
**/
function _checkIput_fomartIP(ip){
    return (ip+256).toString(2).substring(1); //格式化输出(补零)
}
//IP转成整型
function _ip2int(ip){
    var num = 0;
    ip = ip.split(".");
    num = Number(ip[0]) * 256 * 256 * 256 + Number(ip[1]) * 256 * 256 + Number(ip[2]) * 256 + Number(ip[3]);
    num = num >>> 0;
    return num;
} 
//整型解析为IP地址
function _int2iP(num){
    var str;
    var tt = new Array();
    tt[0] = (num >>> 24) >>> 0;
    tt[1] = ((num << 8) >>> 24) >>> 0;
    tt[2] = (num << 16) >>> 24;
    tt[3] = (num << 24) >>> 24;
    str = String(tt[0]) + "." + String(tt[1]) + "." + String(tt[2]) + "." + String(tt[3]);
    return str;
}
//IP转长整型值用以判断IP地址是否相等
function ip2long(v){
	var output = null, parts;
	if(check_ipv4(v)){
		parts = v.split(".");
		output = (Number(parts[0])*256*256*256) + (Number(parts[1])*256*256) + Number(parts[2])*256 + Number(parts[3]);
	}
	return output;
}
//长整型数字转为IPv4格式
function long2ip(v){
	var arr = new Array(4);
	var num = v;
	var i = 3;
	while(i >= 0){
		arr[i] = num%256;
		num = parseInt(num/256);
		i--;
	}
	return arr.join(".");
}
//获取掩码长度
function get_mask_len(mask){
	var cnt = 0;
	var maskArray = mask.split("."); 
	var ip1 = parseInt(maskArray[0]);  
	var ip2 = parseInt(maskArray[1]);  
	var ip3 = parseInt(maskArray[2]);  
	var ip4 = parseInt(maskArray[3]);  
	var ip_binary = _checkIput_fomartIP(ip1) + _checkIput_fomartIP(ip2) + _checkIput_fomartIP(ip3) 
			 + _checkIput_fomartIP(ip4); 
	for (var j=0; j<ip_binary.length; j++){
		if ('1' == ip_binary[j]){
			cnt++;
		}
	}
	return cnt;
}
//传入len为整数，ver为字符串‘v4’or 'v6'
function create_mask(len, ver){
	var mk = "",mz="";
	for(var i=0;i<128;i++){
		mk += "1";
		mz += "0";
	}
	var ret = {
		"v4":function(lens){
			if(lens<0 || lens > 32){
				return -2; //长度超出IPv4的允许长度
			}
			var bin = mk.slice(0, lens) + mz.slice(0, 32 - lens);
			var n = parseInt(bin,2);
			return long2ip(n);
		},
		"v6": function(lens){
			if(lens <0 || lens > 128){
				return -3; //传入长度不符合IPv6要求
			}
			var bin = mk.slice(0, lens) + mz.slice(0, 128 - lens);
			var tmp = [], sbin,tbin;
			for(var i=0;i<8;i++){
				sbin = bin.slice(i*16, (i+1)*16);
				tbin = parseInt(sbin, 2);
				tmp.push(tbin.toString(16));
			}
			return tmp.join(":");
		}
	};
	return (!ret[ver])?-1:ret[ver](len);
}

//操作返回
function doreturn(url){
	location.href = url+ "?rand=" + Math.random();
}

//登录退出
function p_loginout(){
	confim_msg("您确定退出本系统吗？", function(){ 
         loginout();
	});
}
function loginout(){
	xmit.post({url:"/cgi-bin/login.cgi",data:"action=loginout",onrcv:function(){},beforeSend:function(){},error:function(){},timeout:3000,async:false});
    clearCookie();	
	window.top.location.replace("../login.html");
}
//全选复选框事件
function checkAlls(e,str){  
	var a = document.getElementsByName(str);    
	var n = a.length;    
	for (var i=0; i<n; i=i+1)    
		a[i].checked =e.checked;    
}
//获取请求URL
function GetRequest() { 
   var url = location.search; 
   url = decodeURI(url);
   var theRequest = new Object(); 
   if (url.indexOf("?") != -1) { 
      var str = url.substr(1); 
      strs = str.split("&"); 
      for(var i = 0; i < strs.length; i ++) { 
         theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]); 
      } 
   } 
   return theRequest; 
} 
//获取当前时间
function getNewDate(formatStr){	
	var d=new Date();	 
	var str = formatStr;   
  
    str=str.replace(/yyyy|YYYY/,d.getFullYear());   
    str=str.replace(/yy|YY/,(d.getYear() % 100)>9?(d.getYear() % 100).toString():'0' + (d.getYear() % 100));   
  
    str=str.replace(/MM/,(d.getMonth()+1)>9?(d.getMonth()+1).toString():'0' + (d.getMonth()+1));   
    str=str.replace(/M/g,d.getMonth());   
  
  
    str=str.replace(/dd|DD/,d.getDate()>9?d.getDate().toString():'0' + d.getDate());   
    str=str.replace(/d|D/g,d.getDate());   
  
    str=str.replace(/hh|HH/,d.getHours()>9?d.getHours().toString():'0' + d.getHours());   
    str=str.replace(/h|H/g,d.getHours());  
	
    str=str.replace(/mm/,d.getMinutes()>9?d.getMinutes().toString():'0' + d.getMinutes());   
    str=str.replace(/m/g,d.getMinutes());   
  
    str=str.replace(/ss|SS/,d.getSeconds()>9?d.getSeconds().toString():'0' + d.getSeconds());   
    str=str.replace(/s|S/g,d.getSeconds());  
	
	str=str.replace(/ms/g,d.getMilliseconds());  
  
    return str;  
}

function getInfo(name){
   var iBrowseFlg = CookieEnable(); 
   if(iBrowseFlg == 1){
      return getCookie(name);
   }else{
      var info = $(window.parent.document).find("#loginparams").val();
	  alert_msg("cookieinfo:"+info);
	  if(info != ""){
		  try{
			  var data = info.split('|');
			  for(var i=0;i<data.length;i++){
				  var dd = data[i].split('=');
				  if(name == dd[0]){
				      return dd[1];			  
				  }
			  }
			  return "";
		  }catch(e){
		       return "";
		  }
	  }else{
	     return "";
	  }
   }
}

var timers = 0;
//开始刷新
function startAutoRefresh(oldvalue,value) {
	if (value > -1) {
		document.getElementById('s_refresh').options[0].text = value  + '秒';
		document.getElementById('s_refresh').options[0].value = oldvalue;
		document.getElementById('s_refresh').options[0].selected = true;
		value = value - 1;
		timers = setTimeout('startAutoRefresh("' + oldvalue + '","' + value + '")',1000);
		$("#b_stop").css("display","");
	}else {
		$("#b_refresh").click();  //调用一下刷新按钮的事件
		startAutoRefresh(oldvalue,oldvalue);
	}
}

//停止刷新
function stopAutoRefresh(){
    clearTimeout(timers);
	document.getElementById('s_refresh').options[0].text = '不刷新';
	document.getElementById('s_refresh').options[0].value = '-1';
	$("#b_stop").css("display","none");			
}
//弹出提示框样式
function P_alert_msg(msg,callback){
    $.alertMsg(msg,callback);
}

function P_prompt_msg(msg,interval_time,callback){
    $.promptMsg(msg,interval_time,callback);
}

function P_prompt_stanby_msg(msg,interval_time,middle,callback){
    $.promptMsg_stanby(msg,interval_time,middle,callback);
}

function P_confim_msg(msg,callback){
    $.confirmMsg(msg,callback);
}

function P_info_msg(msg){
    $.informationMsg(msg);
}

function confim_pw_msg(msg,callback){
    $.confirm_pwMsg(msg,callback);
}

function alert_msg(msg,callback){
	try{
   	   window.parent.P_alert_msg(msg,callback); 
	}catch(e){
	   P_alert_msg(msg,callback);  
	}
}

function prompt_msg(msg,interval_time,callback){
   	try{
   	   window.parent.P_prompt_msg(msg,interval_time,callback); 
	}catch(e){
	   P_prompt_msg(msg,interval_time,callback); 
	}
}

function prompt_stanby_msg(msg,interval_time,middle,callback){
   	try{
   	   window.parent.P_prompt_stanby_msg(msg,interval_time,middle,callback); 
	}catch(e){
	   P_prompt_stanby_msg(msg,interval_time,middle,callback); 
	}
}

function confim_msg(msg,callback){
   try{
      window.parent.P_confim_msg(msg,callback); 
   }catch(e){
      P_confim_msg(msg,callback); 
   } 
}

function info_msg(msg){
   try{
      window.parent.P_info_msg(msg); 
   }catch(e){
      P_info_msg(msg); 
   } 
}

//关机操作
var off_bar_times = 0;
function off_mask(){
   $("#off-mask").show();
   off_bar_times = window.setInterval("off_go_bar()",100); 
}

function off_go_bar(){ 
	document.getElementById("bar_s").style.width = parseInt(document.getElementById("bar_s").style.width) + 1 + "%"; 
	document.getElementById("bar_v").innerHTML = document.getElementById("bar_s").style.width; 
	if(document.getElementById("bar_s").style.width == "100%"){ 
	      window.clearInterval(off_bar_times); 
		  $("#bar_v").css("color","#00FF00");
		  window.setTimeout("off_div_hide()", 900);
    } 
}  

function off_div_hide(){
   	$("#div_bar").hide();
	$("#off_imag").show();
    $("#mg").html("您已关机！"); 
}

//二级子窗体的页面变动
function change_contentFrame_height(){
	Pvs.resizeContentFrame();
	Pvs.hideMessage();
}

//修改top和title信息
function change_top_title(hostname,ip){
	$("#hostname").html(html_substr(hostname,20));
	$("#ip").html(ip);
	change_title(hostname,ip);
}

function checkErrorInfo(result){
	 if(result == ERR_LOGINOUT){
		 loginout();
	 }else if(result == ERR_NOT_LOGIN){
		 alert_msg("用户未登录，请先登录！",loginout);
	 }else if(result == ERR_REPEAT_LOGIN){
	     alert_msg("该用户已在其它地方登录，请重新登录！",loginout);
	 }else if(result == ERR_COOKIE){
		 alert_msg("登录超时，请重新登录！",loginout);
	 }/*else if(result == ERR_TOKEN){
		 alert_msg("请刷新页面！",pagereload);
	 }*/else if(result == ERR_FILE_NOT_EXIST){
	   	 alert_msg("控制台已重启，请重新登录！",loginout);
	 }else if(result == ERR_AD_NOT_EXIST){
		 alert_msg("系统正在恢复配置，稍候请重新登录！",loginout);
	 }else if(result == ""){
		 alert_msg("操作失败，请求异常！");
	 }else if(result == ERR_FAILURE){
	     alert_msg("操作失败！");
	 }else if(result == ERR_NAME_REPEAT){
		alert_msg("该名称已存在，请重新输入！",getFocus_Name);
	 }else if(result == ERR_NOTFOUND){
		alert_msg("未查找到该条记录！",callback_f);
	 }else{
		return true;
	 }
	 
	 return false; 
}

function pagereload(){
 // location.replace(location.href);
    location.reload(true);
}

function getFocus_Name(){
	$("#name").focus();
}

function initToken(){
	xmit.post({url:'/frame_main.fcgi?action=gettoken',async:false,beforeSend:function(){},onrcv:function(result){
		//if(checkErrorInfo(result)){
			$("#pvs_token").val(result);
		//}
	}}); 
}

var cur_wz_add = "新建";
var cur_wz_edit = "修改";
var cur_wz_copy = "复制";
var cur_wz_find = "查看";
var cur_wz_back = "";

function p_initTable(url,colspan_num){ 
	 var pageindex = $("#txtPage").val();
	 if(" " == pageindex || null == pageindex){pageindex = 1;}
	 var pagesize = $("#pageSize").val();
	 if(" " == pagesize || null == pagesize){pagesize = pageSize;}
	 
	 xmit.post({url:url,onrcv:showall,data:{pageIndex:pageindex,pageSize:pagesize},error:      
	   function(){
			$("#content_main").html("<tr><td align='center'  colspan='"+colspan_num+"'>无记录</td></tr>");
			alert_msg("提交出错，请稍候再试！"); 
			change_contentFrame_height();	
	   }
	 });
	 
	//如果全选是选中的状态，则自己要变成不被选中
	if ($('#select_all').is(':checked')) {
	    $('#select_all').removeAttr("checked");
	}	  
}

function p_del(url,s_fun){
	var selected=document.getElementsByName("id");
	var n=0;		//统计勾选中的个数
	var ids="";
	for(i=0;i<selected.length;i=i+1){
		if(selected[i].checked==true){
			ids=ids+selected[i].value;
			ids=ids+","
			n=n+1;
		}
	}
	ids=ids.substring(0,ids.lastIndexOf(','));
	if(n<1){alert_msg("请选择一个或多个进行删除操作！");return;}
	confim_msg("确定要删除所选？", function(){									  
		xmit.post({url:url,data:"ids="+ids,onrcv:s_fun}); 
	});
}

function p_list_fun(url,op_name,s_fun){
	var selected=document.getElementsByName("id");
	var n=0;		//统计勾选中的个数
	var ids="";
	for(i=0;i<selected.length;i=i+1){
		if(selected[i].checked==true){
			ids=ids+selected[i].value;
			ids=ids+","
			n=n+1;
		}
	}
	ids=ids.substring(0,ids.lastIndexOf(','));
	if(n<1){alert_msg("请选择一个或多个进行"+op_name+"操作！");return;}	  
	xmit.post({url:url,data:"ids="+ids,onrcv:s_fun});
}

var alert_flag = false;
function mousedown_alert_net(){
  if(alert_flag){		
	$('#net option:first').remove();
	alert_flag = false;
  }
}

function change_alert_net(){
  if($("#net").val() == ""){
	  $(".ui-button").eq(1).attr("disabled","disabled");
  }else{
	  $(".ui-button").eq(1).attr("disabled",false);
  }
}

/*告警模块的配置发送接口的方法*/

function alarm_module_net_smtp(op){
   if(op == "show"){
   	   $("#alarm_module").show();
   }else if(op == "hide"){
   	   $("#alarm_module").hide();
   }
}

function alarm_module_net(){
	var message = "<table><tr><td align='right'>发送接口：</td><td align='left'><select id='net' name='net' onmousedown='mousedown_alert_net();' onchange='change_alert_net();'><option value=''>--请选择--</option></select></td></tr></table>";
	
	var type = $("#pagemenu > li > a.current_a").attr("id");
	
	P_confim_msg(message,function(){
		if(type == "smtp"){					  
             $("#contentFrame").contents().find("#net_if").val($("#net").val());
		}else{
			 var net_id = $("#net").val();	
			 if(net_id == ""){
				P_alert_msg("请选择发送接口！");
				return false;
			 }
			 xmit.post({url:'/sysalerts.fcgi?action=save_net_info',data:"net_id="+net_id+"&type="+type,onrcv:function(result){
					if(checkErrorInfo(result)){
						var array = result.split('|'); 
						if(result == ERR_SUCCESS){
							alert_msg("保存成功！");
						}else if(array[0] == ERR_ALERT_IF_DISABLE){
							alert_msg(array[1]);
						}
					}
			 }});
		}
	});
	$("#ui-id-2").html("配置发送接口");
	
	xmit.post({url:'/net_if.fcgi?action=getwan',async:false,beforeSend:function(){},onrcv:function(result){
			if(checkErrorInfo(result)){
				 var data = eval('('+result+')');
				 var tmp = data["net_if"];
				 for(var i=0; i<tmp.length; i++){
					 $("#net").append('<option value="'+tmp[i].id+'">'+htmlEncode(tmp[i].name)+'</option>');
				 }
			 }
	}}); 
	
	if(type == "smtp"){	
	   var op_smtp = $("#contentFrame").contents().find("#op").val();
	   var smtpid = $("#contentFrame").contents().find("#id").val();
	  // if(op_smtp == "add"){
			xmit.post({url:'/smtp.fcgi?action=get_net_info',data:"smtpid="+smtpid,beforeSend:function(){},onrcv:function(result){
				if(checkErrorInfo(result)){
					var data = eval('('+result+')');	
					$("#net").val(data.id);			
					if($("#net").val() == null){  
						if(data.enable == "1"){
							alert_flag = true;
							$("#net").prepend("<option value='"+data.id+"'>"+data.name+"(已禁用)</option>"); //为Select插入一个Option(第一个位置) 
						}else{
							$("#net").val('');
						}
					}
				}
			}}); 
	 //  }else{		
	//		var net_if = $("#contentFrame").contents().find("#net_if").val();
	//		$("#net").val(net_if);
	//   }
	}else{	
		var smtpid = 0;      
		if(type == "mail_alert"){smtpid = $("#contentFrame").contents().find("#smtp").val();}
		xmit.post({url:'/sysalerts.fcgi?action=get_net_info',data:"type="+type+"&smtpid="+smtpid,beforeSend:function(){},onrcv:function(result){
			if(checkErrorInfo(result)){
				var data = eval('('+result+')');	
				$("#net").val(data.id);			
				if($("#net").val() == null){  
					if(data.enable == "1"){
						alert_flag = true;
						$("#net").prepend("<option value='"+data.id+"'>"+data.name+"(已禁用)</option>"); //为Select插入一个Option(第一个位置) 
					}else{
						$("#net").val('');
					}
				}else{
				   if(data.edit_flag == "0"){
					   $("#net").attr("disabled","disabled");
					   $(".ui-button").eq(1).attr("disabled","disabled");
				   }
				}
			}
		}}); 
	}
}

function base64_decode(str){
	var c1, c2, c3, c4;
	var base64DecodeChars = new Array(
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57,  
		58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0,  1,  2,  3,  4,  5,  6,
		7,  8,  9,  10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
		25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
		37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1,
		-1, -1
	);
	var i=0, len = str.length, string = '';
	
	while (i < len){
		do{
			c1 = base64DecodeChars[str.charCodeAt(i++) & 0xff]
		} while (
			i < len && c1 == -1
		);	
		if (c1 == -1) break;	
		do{
			c2 = base64DecodeChars[str.charCodeAt(i++) & 0xff]
		} while (
			i < len && c2 == -1
		);	
		if (c2 == -1) break;		
		string += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));	
		do{
			c3 = str.charCodeAt(i++) & 0xff;
			if (c3 == 61)
			return string;		
			c3 = base64DecodeChars[c3]
		} while (
			i < len && c3 == -1
		);	
		if (c3 == -1) break;		
		string += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));	
		do{
			c4 = str.charCodeAt(i++) & 0xff;
			if (c4 == 61) return string;
			c4 = base64DecodeChars[c4]
		} while (
			i < len && c4 == -1
		);	
		if (c4 == -1) break;		
		string += String.fromCharCode(((c3 & 0x03) << 6) | c4)
	}
	return string;
}