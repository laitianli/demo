﻿if (window.location != window.top.location){
	window.top.location = window.location;
}

$(document).ready(function(){	
	
	xmit.post({url:"/cgi-bin/login.cgi",data:"action=getstat",onrcv:function(result){
		if(result != "" && result == ERR_SUCCESS){
			window.location.href = "index.html" ; 
		}
	}});
	
   	/*if (getCookie("sessionId") == null) {
		 deleteStatefulCookies();
	}*/
});

function deleteStatefulCookies() {
	delCookie("formpage");
}

/*按回车登录*/
function keydown(e){        
	var currKey=0,e=e||event;
    if(e.keyCode==13)
		 doLogin(document.getElementById('login_btn'));     
}
document.onkeydown=keydown;

function doClickStyle(obj,objclassname){  
  	document.getElementById(obj).className=objclassname;  
}
  
function changeMouseStyle(obj,shape){
    document.body.style.cursor=shape;  
}

var ver_time= null;
function hideversion(){
	$("#version").slideUp("slow");
	clearTimeout(ver_time);
	ver_time = null;
}

/*登录按钮事件*/
function doLogin(obj){			
	var account=$.trim($("#login_name").val());
	var pass=$("#login_pwd").val();	
	var nowdo=$("#login_btn").val();	

    if(account==null || account=="" ){
		$("#error_msg").html("请输入用户名！");
		changeMouseStyle(obj,"auto");
		$("#login_name").focus();
		return;
	}else if(pass==null || pass==""){
		$("#error_msg").html("请输入密码！");
		changeMouseStyle(obj,"auto");
		$("#login_pwd").focus();
		return;
	}else{
		var previousUsername = getCookie('username');
		if (account != previousUsername) {
			deleteStatefulCookies();
		}
	    $("#error_msg").html("");
	    //xmit.post({url:"/cgi-bin/login.cgi",data:"action=login&name="+account+"&passwd="+pass,onrcv:function(result){
	    $.post("/cgi-bin/login.cgi",{action:nowdo,username:account,passwd:pass},function(result){	
			 if(result == ERR_FAILURE ){
				$("#error_msg").html("操作失败！");
				changeMouseStyle(obj,"auto");
				return;
			 }else if(result == ERR_REPEAT_LOGIN){
			 	$("#error_msg").html("请不要重复登录！");
				changeMouseStyle(obj,"auto");
				changeMouseStyle(obj,"wait");	
				window.location.href = "index.html" ;
				return;
			 }else if(result = ERR_SUCCESS){				
				changeMouseStyle(obj,"wait");	
				window.location.href = "index.html" ; 
			 }else{
			    $("#error_msg").html("登录失败！");
				$("#login_name").val("");
				$("#login_pwd").val("");
				$("#login_name").focus();
				return;
			 }   
		});
	}
}