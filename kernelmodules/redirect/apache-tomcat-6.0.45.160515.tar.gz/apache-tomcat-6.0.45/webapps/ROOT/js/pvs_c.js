//如果跨框架请求，则返回
//if (window == top || !window.parent.Pvs) {
//	window.onerror = function(e){
//		return true;
//	};
//    window.top.location.href= "../";	
//}

var Pvs = new Object();
var api = [
	"initContent",
	"showMessage",
	"hideMessage",
	"resizeFrameHeight"
];

if (window != top && window.parent.Pvs) {
	for (var i in api) {
		if (eval("window.parent.Pvs." + api[i])) {
			eval("Pvs." + api[i] + " = window.parent.Pvs." + api[i]);
		}
		else {
			eval("Pvs." + api[i] + " = window.parent." + api[i]);
		}
	}
}
else {
	for (var i in api) {
		eval("Pvs." + api[i] + " = function() {}");
	}
}

Pvs.initContentEvents = function() {
    if (window.parent && window.parent.Pvs != undefined) {
        window.parent.scrollToTop();
        // Standard Browsers
        try {
            Pvs.addEvent(window,'beforeunload',window.parent.initContentBeforeUnLoad,false);
            Pvs.addEvent(window,'unload',window.parent.initContentUnLoad,false);
        }
        // Internt Explorer
        catch(e) {
            window.attachEvent('onbeforeunload', function(){
                 window.parent.initContentBeforeUnLoad();
            });

            window.attachEvent('onunload', function(){
                 window.parent.initContentUnLoad();
            });
        }
        setInterval(function(){
            try {
                window.parent.resizeFrameHeight('contentFrame');
            }catch(e) {};
        },100);
    }
};

Pvs.addEvent = function(obj,evt,fnc,useCapture) {
	if (!useCapture) {
		useCapture=false;
	}
	if (obj.addEventListener) {
		obj.addEventListener(evt,fnc,useCapture);
		return true;
	}
	else if (obj.attachEvent) {
		return obj.attachEvent("on"+evt,fnc);
	}
};


Pvs.resizeContentFrame = function() {
	var iframeObj = window.parent.document.getElementsByTagName('iframe')[window.name];
	if (window.parent && iframeObj) {
		iframeObj.style.height = window.document.getElementsByTagName('html')[0].scrollHeight + 'px';
	}
};


function showMessage(type) {
	Pvs.showMessage(type);
}

function hideMessage() {
	Pvs.hideMessage();
}
