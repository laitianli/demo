document.writeln("<script language='javascript' src='jQuery/jquery-1.11.2.min.js' type='text/javascript'></script>");
document.writeln("<script language='javascript' src='js/base.js' type='text/javascript'></script>");
document.writeln("<script language='javascript' src='js/common.js' type='text/javascript'></script>");
document.writeln("<script language='javascript' src='js/error.js' type='text/javascript'></script>");
document.writeln("<script language='javascript' src='js/xmit.js' type='text/javascript'></script>");

document.writeln("<script language='javascript' src='js/pvs_c.js' type='text/javascript'></script>");

